# Asian Paints Digital Fandeck POC — v13

This version keeps the v12 Netlify/Sass/JS build fixes and adds the latest interaction and mobile modal polish.

## What changed in v13

- Clicking any fan `card-cap` or `card-strip` opens the shade-details popup for that exact sample colour, not only the active base card colour.
- The popup smart palette is generated from the clicked sample colour.
- The popup save button shortlists the colour currently shown in the popup.
- Fan card strip text is centre-aligned.
- The `+` shortlist icon appears only on desktop hover/focus for the exact cap/strip, not across the whole active card.
- Mobile modal layout is centre-aligned with side gutters, so it does not touch the left/right screen edges.
- Mobile modal open/close animation is stabilised to reduce flicker/blinking on real devices.
- Browse controls are visually separated from the fandeck stage.
- `style.scss` and `script.source.js` include comments for handoff and maintenance.

## Important files

- `index.html` — page markup.
- `style.scss` — editable SCSS source with UI comments.
- `style.css` — compiled CSS used by the page.
- `script.source.js` — editable, commented JavaScript source.
- `script.js` — Babel-compiled browser file used by `index.html`.
- `script.min.js` — pre-minified JS file for production builds if preferred.
- `server.js` — local development proxy only.
- `netlify/functions/shades.js` — Netlify production proxy for live Asian Paints shade data.
- `netlify.toml` and `_redirects` — Netlify routing for `/api/shades` and diagnostics.

## Local development

```bash
npm install
npm start
```

Open:

```text
http://127.0.0.1:8000
```

Diagnostics:

```text
http://127.0.0.1:8000/api/shades/diagnostics
```

## Netlify deployment

Deploy the whole folder, including:

```text
netlify.toml
netlify/functions/shades.js
_redirects
```

Recommended Netlify settings:

```text
Build command: npm run build
Publish directory: .
```

After deployment, verify:

```text
https://YOUR-SITE.netlify.app/.netlify/functions/shades
https://YOUR-SITE.netlify.app/api/shades/diagnostics
```

## SCSS build/minification

The editable SCSS file is `style.scss`. It uses Sass-safe CSS math names such as `Min(...)` and `Clamp(...)` where needed to avoid older Sass/minifier `px` and `%` unit conflicts.

Build CSS:

```bash
npm run build:css
```

Watch CSS while editing:

```bash
npm run watch:css
```

## JavaScript build/minification

Edit `script.source.js`. The runtime file `script.js` is generated with Babel so older minifiers do not choke on optional chaining, arrow functions, async/await, `const`, or `let`.

Build JS:

```bash
npm run build:js
```

Check generated JS:

```bash
npm run check:js
```

Avoid running old `uglify-js` directly on `script.source.js`. Use the build script or `script.min.js`.

## API source rule

There are no hardcoded fallback shade colours. If beta/www Asian Paints does not return usable shade data, the UI shows an API state instead of fake colours.
