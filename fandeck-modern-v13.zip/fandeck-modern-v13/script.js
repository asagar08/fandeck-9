"use strict";

function _regenerator() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag"; function i(r, n, o, i) { var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype); return _regeneratorDefine2(u, "_invoke", function (r, n, o) { var i, c, u, f = 0, p = o || [], y = !1, G = { p: 0, n: 0, v: e, a: d, f: d.bind(e, 4), d: function d(t, r) { return i = t, c = 0, u = e, G.n = r, a; } }; function d(r, n) { for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) { var o, i = p[t], d = G.p, l = i[2]; r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0)); } if (o || r > 1) return a; throw y = !0, n; } return function (o, p, l) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) { i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u); try { if (f = 2, i) { if (c || (o = "next"), t = i[o]) { if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object"); if (!t.done) return t; u = t.value, c < 2 && (c = 0); } else 1 === c && (t = i["return"]) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1); i = e; } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break; } catch (t) { i = e, c = 1, u = t; } finally { f = 1; } } return { value: t, done: y }; }; }(r, o, i), !0), u; } var a = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} t = Object.getPrototypeOf; var c = [][n] ? t(t([][n]())) : (_regeneratorDefine2(t = {}, n, function () { return this; }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c); function f(e) { return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, _regeneratorDefine2(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, _regeneratorDefine2(u, "constructor", GeneratorFunctionPrototype), _regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", _regeneratorDefine2(GeneratorFunctionPrototype, o, "GeneratorFunction"), _regeneratorDefine2(u), _regeneratorDefine2(u, o, "Generator"), _regeneratorDefine2(u, n, function () { return this; }), _regeneratorDefine2(u, "toString", function () { return "[object Generator]"; }), (_regenerator = function _regenerator() { return { w: i, m: f }; })(); }
function _regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } _regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { _regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, _regeneratorDefine2(e, r, n, t); }
function _toConsumableArray(r) { return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArray(r) { if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r); }
function _arrayWithoutHoles(r) { if (Array.isArray(r)) return _arrayLikeToArray(r); }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t["return"] || t["return"](); } finally { if (u) throw o; } } }; }
function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
/* global $, gsap, Draggable, tinycolor */

/**
 * Asian Paints Digital Fandeck
 * ------------------------------------------------------------
 * Data strategy:
 * - On beta.asianpaints.com / asianpaints.com, use the same-origin AEM JSON path.
 *   That means the browser does not hit a cross-domain URL and should not need CORS.
 * - On localhost/127.0.0.1, use the optional Node proxy at /api/shades.
 * - On Netlify, use the bundled serverless function at /.netlify/functions/shades.
 *   A static Netlify deploy cannot run server.js, so the function is the production proxy.
 *
 * UI strategy:
 * - Fan card/strip click opens the shade details modal only.
 * - Plus / save buttons shortlist colours and update the header CTA badge.
 * - Header CTA opens the separate Colour Selection modal.
 */
var SHADE_API_PATH = "/content/ap/en/home/colour-catalogue/jcr%3Acontent/root/responsivegrid_602603264/shadelisting.shade.json?selectedShadeFamily=all&language=en&shadeMapper=false";
var IS_LOCAL_DEV = ["localhost", "127.0.0.1", "0.0.0.0"].includes(window.location.hostname);
var CONFIG = window.ASIAN_PAINTS_FANDECK || {};
var CONFIGURED_DATA_URL = CONFIG.dataUrl || "";
var LOCAL_PROXY_ORIGIN = CONFIG.localProxyOrigin || "http://127.0.0.1:8000";
var IS_PROXY_PORT = window.location.port === "8000";
var IS_NETLIFY_HOST = /(^|\.)netlify\.app$/i.test(window.location.hostname);
var NETLIFY_FUNCTION_URL = "/.netlify/functions/shades";
var DATA_URLS = buildDataUrlCandidates();

/**
 * Builds an ordered data-source list.
 * - On beta.asianpaints.com: try the same-origin AEM JSON path first.
 * - On localhost: try the Node proxy. This also works when you accidentally
 *   open VS Code Live Server on :5500, as long as `npm start` is running.
 * - On custom domains: try /api/shades first so teams can mount a backend proxy.
 * - On Netlify: try the serverless function before the local proxy.
 */
function buildDataUrlCandidates() {
  if (CONFIGURED_DATA_URL) return [CONFIGURED_DATA_URL];
  if (IS_LOCAL_DEV) {
    return uniqueList(IS_PROXY_PORT ? ["/api/shades", "".concat(LOCAL_PROXY_ORIGIN, "/api/shades")] : ["".concat(LOCAL_PROXY_ORIGIN, "/api/shades"), "/api/shades"]);
  }
  if (/asianpaints\.com$/i.test(window.location.hostname)) {
    return [SHADE_API_PATH, "/api/shades", NETLIFY_FUNCTION_URL];
  }
  if (IS_NETLIFY_HOST) {
    return [NETLIFY_FUNCTION_URL, "/api/shades"];
  }
  return ["/api/shades", NETLIFY_FUNCTION_URL, "".concat(LOCAL_PROXY_ORIGIN, "/api/shades")];
}
var MAX_CARDS_DESKTOP = 47;
var MAX_CARDS_MOBILE = 31;
var FAVORITE_KEY = "asianpaints-fandeck-favorites-v1";
var PALETTE_KEY = "asianpaints-fandeck-selection-v1";
var MAX_SELECTION = 8;
var state = {
  all: [],
  filtered: [],
  category: "All",
  selectedIndex: 0,
  selectedId: null,
  favorites: new Set(),
  favoritesOnly: false,
  selectedPalette: [],
  currentSmartPalette: [],
  dragProxy: null,
  isDragging: false,
  lastQuery: "",
  suppressFanClickUntil: 0,
  dataSource: "",
  deckWindow: {
    key: "",
    start: 0,
    end: 0
  },
  swipeFrame: null,
  swipePendingIndex: null,
  // Holds the exact colour currently displayed in the details popup.
  // This can be the main API shade or a generated cap/strip sample.
  currentModalColor: null
};
var dom = {};
$(init);
function init() {
  return _init.apply(this, arguments);
}
function _init() {
  _init = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee() {
    var _state$filtered$;
    var shades, localHint, _t;
    return _regenerator().w(function (_context) {
      while (1) switch (_context.p = _context.n) {
        case 0:
          cacheDom();
          registerPlugins();
          bindEvents();
          loadFavorites();
          loadSelectedPalette();
          renderSelectedPalette();
          setLoading(true);
          _context.p = 1;
          _context.n = 2;
          return fetchShadeData();
        case 2:
          shades = _context.v;
          state.all = prepareShadeList(shades);
          if (state.all.length) {
            _context.n = 3;
            break;
          }
          showDataError("The shade API responded, but no usable colours were found. Please confirm the API returns shade name/code plus HEX or RGB values.");
          return _context.a(2);
        case 3:
          showToast("Loaded ".concat(state.all.length, " Asian Paints shades."));
          _context.n = 5;
          break;
        case 4:
          _context.p = 4;
          _t = _context.v;
          console.warn("Shade data fetch failed.", _t);
          localHint = IS_LOCAL_DEV ? " Start npm with `npm start`. You can open http://127.0.0.1:8000 directly, or keep Live Server open after the proxy is running." : IS_NETLIFY_HOST ? " Confirm netlify/functions/shades.js is deployed and /.netlify/functions/shades returns JSON." : " Confirm the same-origin AEM JSON path, Netlify function, or /api/shades proxy is reachable on this domain.";
          showDataError("Could not load the live Asian Paints shade API.".concat(localHint));
          console.warn("Shade data source attempts:", _t.details || _t.message);
          return _context.a(2);
        case 5:
          state.filtered = _toConsumableArray(state.all);
          state.selectedId = ((_state$filtered$ = state.filtered[0]) === null || _state$filtered$ === void 0 ? void 0 : _state$filtered$.id) || null;
          buildCategoryTabs();
          applyFilter("All", {
            silent: true
          });
          setupGsapIntro();
          setupDraggable();
          setLoading(false);
        case 6:
          return _context.a(2);
      }
    }, _callee, null, [[1, 4]]);
  }));
  return _init.apply(this, arguments);
}
function cacheDom() {
  dom.body = $(document.body);
  dom.fanDeck = $("#fanDeck");
  dom.fanStage = $("#fanStage");
  dom.tabs = $("#categoryTabs");
  dom.range = $("#rangeSlider");
  dom.rangeCount = $("#rangeCount");
  dom.search = $("#shadeSearch");
  dom.clearSearch = $("#clearSearch");
  dom.suggestions = $("#suggestions");
  dom.progressText = $("#progressText");
  dom.shadeTotal = $("#shadeTotal");
  dom.progressFill = $("#progressFill");
  dom.progressKnob = $("#progressKnob");
  dom.progressTrack = $("#progressTrack");
  dom.selectedBeacon = $("#selectedBeacon");
  dom.beaconSwatch = $(".beacon-swatch");
  dom.beaconName = $(".beacon-copy strong");
  dom.beaconMeta = $(".beacon-copy small");
  dom.activeFamily = $("#activeFamily");
  dom.activeName = $("#activeName");
  dom.activeCode = $("#activeCode");
  dom.activeHex = $("#activeHex");
  dom.activeRgb = $("#activeRgb");
  dom.previewWall = $("#previewWall");
  dom.favoriteCurrent = $("#favoriteCurrent");
  dom.favoriteTray = $("#favoriteTray");
  dom.toggleFavorites = $("#toggleFavorites");
  dom.openDetails = $("#openDetails");
  dom.randomShade = $("#randomShade");
  dom.prevShade = $("#prevShade");
  dom.nextShade = $("#nextShade");
  dom.resetDeck = $("#resetDeck");
  dom.overlay = $("#modalOverlay");
  dom.selectionOverlay = $("#selectionOverlay");
  dom.closeModal = $("#closeModal");
  dom.closeSelectionModal = $("#closeSelectionModal");
  dom.modalSwatch = $("#modalSwatch");
  dom.modalFamily = $("#modalFamily");
  dom.modalShadeName = $("#modalShadeName");
  dom.modalShadeCode = $("#modalShadeCode");
  dom.modalHex = $("#modalHex");
  dom.modalRgb = $("#modalRgb");
  dom.modalCode = $("#modalCode");
  dom.smartPalette = $("#smartPalette");
  dom.selectionBento = $("#selectionBento");
  dom.selectionCount = $("#selectionCount");
  dom.clearSelection = $("#clearSelection");
  dom.selectionBadge = $("#selectionBadge");
  dom.paletteHint = $("#paletteHint");
  dom.modalFavorite = $("#modalFavorite");
  dom.modalNext = $("#modalNext");
  dom.toast = $("#toast");
}
function registerPlugins() {
  if (window.gsap && window.Draggable) gsap.registerPlugin(Draggable);
}
function bindEvents() {
  // Range/arrow controls update the selected shade without page-scroll side effects.
  dom.range.on("input", function () {
    setSelectedIndex(Number(this.value), {
      source: "range"
    });
  });
  dom.prevShade.on("click", function () {
    return stepShade(-1);
  });
  dom.nextShade.on("click", function () {
    return stepShade(1);
  });
  dom.modalNext.on("click", function () {
    stepShade(1);
    openModal(getSelectedShade());
  });
  dom.resetDeck.on("click", function () {
    setSelectedIndex(0, {
      source: "reset"
    });
    pulseDeck();
  });
  dom.randomShade.on("click", function () {
    if (!state.filtered.length) return;
    var randomIndex = Math.floor(Math.random() * state.filtered.length);
    setSelectedIndex(randomIndex, {
      source: "random"
    });
    openModal(getSelectedShade());
  });
  dom.progressTrack.on("click", function (event) {
    var rect = this.getBoundingClientRect();
    var ratio = clamp((event.clientX - rect.left) / rect.width, 0, 1);
    setSelectedIndex(Math.round(ratio * (state.filtered.length - 1)), {
      source: "progress"
    });
  });

  // Header CTA is the only entry point for the Colour Selection popup.
  dom.openDetails.on("click", openSelectionModal);
  dom.selectedBeacon.on("click", function () {
    return openModal(getSelectedShade());
  });
  dom.closeModal.on("click", closeModal);
  dom.closeSelectionModal.on("click", closeSelectionModal);
  dom.overlay.on("click", function (event) {
    if (event.target === dom.overlay[0]) closeModal();
  });
  dom.selectionOverlay.on("click", function (event) {
    if (event.target === dom.selectionOverlay[0]) closeSelectionModal();
  });
  dom.favoriteCurrent.on("click", function () {
    return shortlistShade(getSelectedShade(), dom.favoriteCurrent[0]);
  });
  dom.modalFavorite.on("click", function () {
    return shortlistShade(state.currentModalColor || getSelectedShade(), dom.modalFavorite[0]);
  });
  dom.toggleFavorites.on("click", toggleFavoritesFilter);
  dom.search.on("input", debounce(handleSearchInput, 80));
  dom.search.on("keydown", function (event) {
    if (event.key === "Enter") {
      event.preventDefault();
      var first = dom.suggestions.find(".suggestion-item").first();
      if (first.length) selectById(first.data("id"), {
        source: "search",
        open: true
      });
    }
    if (event.key === "Escape") clearSearch();
  });
  dom.clearSearch.on("click", clearSearch);
  dom.suggestions.on("click", ".suggestion-item", function () {
    selectById($(this).data("id"), {
      source: "search",
      open: true
    });
    dom.suggestions.hide();
  });

  // Plus buttons shortlist exact strip colours without opening the details popup.
  dom.fanDeck.on("click", ".strip-add", function (event) {
    if (shouldSuppressFanClick()) {
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
    var sampleNode = $(this).closest(".card-cap, .card-strip");
    var card = $(this).closest(".fan-card");
    var shade = state.all.find(function (item) {
      return item.id === card.data("id");
    });
    if (!shade || !sampleNode.length) return;
    var index = state.filtered.findIndex(function (item) {
      return item.id === shade.id;
    });
    if (index >= 0) setSelectedIndex(index, {
      source: "shortlist"
    });
    var sample = paletteItemFromElement(shade, sampleNode[0]);
    savePaletteColor(sample, {
      origin: this
    });
  });

  // Clicking a card cap/strip opens the details popup for that exact sample.
  // The fan card still becomes active, but the popup uses the clicked tile colour,
  // role, and generated tint instead of always showing the base card shade.
  dom.fanDeck.on("click", ".card-cap, .card-strip", function (event) {
    if (shouldSuppressFanClick()) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    var card = $(this).closest(".fan-card");
    var shade = state.all.find(function (item) {
      return item.id === card.data("id");
    });
    if (!shade) return;
    var index = state.filtered.findIndex(function (item) {
      return item.id === shade.id;
    });
    if (index >= 0) setSelectedIndex(index, {
      source: "strip"
    });
    var sample = shadeSampleFromElement(shade, this);
    openModal(sample || getSelectedShade(), {
      sample: sample
    });
  });
  dom.fanDeck.on("click", ".fan-card", function (event) {
    if (shouldSuppressFanClick()) {
      event.preventDefault();
      return;
    }
    if ($(event.target).closest(".card-cap, .card-strip, .card-fav, .strip-add").length) return;
    var id = $(this).data("id");
    var index = state.filtered.findIndex(function (shade) {
      return shade.id === id;
    });
    if (index >= 0) {
      setSelectedIndex(index, {
        source: "card"
      });
      openModal(getSelectedShade());
    }
  });
  dom.fanDeck.on("click", ".card-fav", function (event) {
    if (shouldSuppressFanClick()) {
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
    var card = $(this).closest(".fan-card");
    var shade = state.all.find(function (item) {
      return item.id === card.data("id");
    });
    var index = state.filtered.findIndex(function (item) {
      return item.id === (shade === null || shade === void 0 ? void 0 : shade.id);
    });
    if (index >= 0) setSelectedIndex(index, {
      source: "shortlist"
    });
    shortlistShade(shade, this);
  });
  dom.favoriteTray.on("click", ".selection-mini", function () {
    var shadeId = $(this).data("shadeId");
    if (shadeId) selectById(shadeId, {
      source: "selection"
    });
  });

  // Compact tray CTA opens the dedicated Colour Selection popup.
  dom.favoriteTray.on("click", ".review-selection", function () {
    openSelectionModal();
  });
  dom.selectionBento.on("click", ".remove-selection", function (event) {
    event.preventDefault();
    event.stopImmediatePropagation();
    removePaletteColor($(this).data("key"));
  });
  dom.selectionBento.on("click", ".selection-card", function (event) {
    if ($(event.target).closest(".remove-selection").length) return;
    var shadeId = $(this).data("shadeId");
    if (!shadeId) return;
    closeSelectionModal({
      instant: true
    });
    selectById(shadeId, {
      source: "selection-popup",
      open: true
    });
  });
  dom.clearSelection.on("click", clearSelectedPalette);
  $(document).on("keydown", function (event) {
    var _document$activeEleme;
    var isTyping = ["INPUT", "TEXTAREA"].includes((_document$activeEleme = document.activeElement) === null || _document$activeEleme === void 0 ? void 0 : _document$activeEleme.tagName);
    if (event.key === "Escape") {
      closeModal();
      closeSelectionModal();
    }
    if (event.key === "/" && !isTyping) {
      event.preventDefault();
      dom.search.trigger("focus");
    }
    if (!isTyping && event.key === "ArrowLeft") stepShade(-1);
    if (!isTyping && event.key === "ArrowRight") stepShade(1);
    if (!isTyping && event.key === "Enter") openModal(getSelectedShade());
  });
  $(".copy-chip").on("click", function () {
    var shade = getSelectedShade();
    if (!shade) return;
    var type = $(this).data("copy");
    var value = type === "rgb" ? shade.rgbText : type === "code" ? shade.code : shade.hex;
    copyToClipboard(value);
  });
  $(window).on("resize", debounce(function () {
    renderDeck({
      animate: false
    });
    setupDraggable();
  }, 160));
}
function fetchShadeData() {
  return _fetchShadeData.apply(this, arguments);
}
function _fetchShadeData() {
  _fetchShadeData = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee2() {
    var errors, _iterator3, _step3, url, _payload$meta, response, rawText, payload, raw, shades, error, _t2, _t3;
    return _regenerator().w(function (_context2) {
      while (1) switch (_context2.p = _context2.n) {
        case 0:
          // Use text + JSON.parse so we can surface cleaner errors if an AEM path returns
          // an HTML error page, an empty response, or a JSON wrapper with no colours.
          errors = [];
          _iterator3 = _createForOfIteratorHelper(DATA_URLS);
          _context2.p = 1;
          _iterator3.s();
        case 2:
          if ((_step3 = _iterator3.n()).done) {
            _context2.n = 10;
            break;
          }
          url = _step3.value;
          _context2.p = 3;
          _context2.n = 4;
          return fetch(url, {
            cache: "no-store",
            headers: {
              Accept: "application/json,text/plain,*/*"
            }
          });
        case 4:
          response = _context2.v;
          _context2.n = 5;
          return response.text();
        case 5:
          rawText = _context2.v;
          if (response.ok) {
            _context2.n = 6;
            break;
          }
          errors.push("".concat(url, " \u2192 HTTP ").concat(response.status));
          return _context2.a(3, 9);
        case 6:
          payload = parsePossiblyWrappedJson(rawText);
          state.dataSource = (payload === null || payload === void 0 || (_payload$meta = payload.meta) === null || _payload$meta === void 0 ? void 0 : _payload$meta.source) || (payload === null || payload === void 0 ? void 0 : payload.source) || (IS_LOCAL_DEV ? "local-proxy" : IS_NETLIFY_HOST ? "netlify-function" : "same-origin-aem-json");

          // The local server and Netlify function return { shades: [...] }. The beta/www
          // AEM endpoint may return a nested JSON structure, so extractShadeObjects walks it.
          raw = Array.isArray(payload === null || payload === void 0 ? void 0 : payload.shades) ? payload.shades : extractShadeObjects(payload);
          shades = raw.map(function (item, index) {
            return normalizeShade(item, index);
          }).filter(Boolean);
          if (!shades.length) {
            _context2.n = 7;
            break;
          }
          return _context2.a(2, shades);
        case 7:
          errors.push("".concat(url, " \u2192 JSON loaded but no usable HEX/RGB colours were found"));
          _context2.n = 9;
          break;
        case 8:
          _context2.p = 8;
          _t2 = _context2.v;
          errors.push("".concat(url, " \u2192 ").concat(_t2.message));
        case 9:
          _context2.n = 2;
          break;
        case 10:
          _context2.n = 12;
          break;
        case 11:
          _context2.p = 11;
          _t3 = _context2.v;
          _iterator3.e(_t3);
        case 12:
          _context2.p = 12;
          _iterator3.f();
          return _context2.f(12);
        case 13:
          error = new Error("No configured Asian Paints shade source returned usable colour data.");
          error.details = errors;
          throw error;
        case 14:
          return _context2.a(2);
      }
    }, _callee2, null, [[3, 8], [1, 11, 12, 13]]);
  }));
  return _fetchShadeData.apply(this, arguments);
}
function parsePossiblyWrappedJson(text) {
  var trimmed = String(text || "").trim();
  if (!trimmed) throw new Error("Shade API returned an empty response.");

  // AEM services sometimes prefix JSON responses. Strip a common anti-XSSI
  // prefix before parsing.
  var cleaned = trimmed.replace(/^\)\]\}'\s*,?\s*/, "");
  try {
    return JSON.parse(cleaned);
  } catch (error) {
    throw new Error("Shade API did not return valid JSON. First characters: ".concat(cleaned.slice(0, 80)));
  }
}
function extractShadeObjects(payload) {
  var result = [];
  var seen = new WeakSet();
  function walk(node) {
    var context = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    if (!node || _typeof(node) !== "object") return;
    if (seen.has(node)) return;
    seen.add(node);
    if (Array.isArray(node)) {
      node.forEach(function (child) {
        return walk(child, context);
      });
      return;
    }
    var nextContext = _objectSpread(_objectSpread({}, context), {}, {
      family: readAny(node, ["shadeFamily", "shadefamily", "shadeFamilyName", "family", "familyName", "colourFamily", "colorFamily", "colourFamilyName", "colorFamilyName", "filterName", "category", "categoryName", "shadeGroup", "shadeGroupName", "groupName"]) || context.family
    });
    if (looksLikeShade(node)) {
      result.push(_objectSpread(_objectSpread({}, node), {}, {
        __contextFamily: nextContext.family || context.family
      }));
    }
    Object.entries(node).forEach(function (_ref) {
      var _ref2 = _slicedToArray(_ref, 2),
        key = _ref2[0],
        value = _ref2[1];
      var childContext = nextContext;
      if (_typeof(value) === "object" && value) {
        var prettyKey = prettifyKey(key);
        if (isLikelyFamilyName(prettyKey)) childContext = _objectSpread(_objectSpread({}, nextContext), {}, {
          family: prettyKey
        });
      }
      walk(value, childContext);
    });
  }
  walk(payload);
  return result;
}
function looksLikeShade(obj) {
  var hasNameOrCode = Boolean(readAny(obj, ["shadeName", "shade_name", "shadename", "name", "colourName", "colorName", "title", "shadeTitle", "label", "shade", "displayName", "productName", "colorLabel", "colourLabel"]) || readAny(obj, ["shadeCode", "shade_code", "code", "shadeNo", "shadeNumber", "colourCode", "colorCode", "shadeId", "id"]));
  var hasColor = Boolean(extractHex(obj) || readAny(obj, ["rgb", "shadeRGB", "shadeRgb", "rgbValue", "colorRgb", "colourRgb"]));
  return hasNameOrCode && hasColor;
}
function normalizeShade(obj, index) {
  var hex = normalizeHex(extractHex(obj));
  if (!hex) return null;
  var code = cleanText(readAny(obj, ["shadeCode", "shade_code", "shadecode", "code", "shadeNo", "shadeNumber", "shadeNbr", "shadeNum", "colourCode", "colorCode", "colour_code", "color_code", "shadeId", "id", "sapCode", "sku", "colorId", "colourId"])) || "C".concat(String(index + 1).padStart(4, "0"));
  var name = cleanText(readAny(obj, ["shadeName", "shade_name", "shadename", "name", "colourName", "colorName", "title", "shadeTitle", "label", "shade", "displayName", "productName", "colorLabel", "colourLabel"])) || "Shade ".concat(code);
  var rawFamily = cleanText(readAny(obj, ["shadeFamily", "shadefamily", "shadeFamilyName", "family", "familyName", "colourFamily", "colorFamily", "colourFamilyName", "colorFamilyName", "filterName", "category", "categoryName", "shadeGroup", "shadeGroupName", "groupName"]) || obj.__contextFamily) || autoFamily(hex);
  var normalizedFamily = normalizeFamily(rawFamily);
  var family = normalizedFamily === "All" ? autoFamily(hex) : normalizedFamily;
  var rgb = hexToRgb(hex);
  var hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
  return {
    id: "".concat(slugify(code), "-").concat(slugify(name), "-").concat(index),
    name: name,
    code: String(code).trim(),
    hex: hex,
    family: family,
    rgb: rgb,
    rgbText: "".concat(rgb.r, ", ").concat(rgb.g, ", ").concat(rgb.b),
    hsl: hsl,
    estimated: Boolean(obj.estimated || obj.isApprox),
    isApprox: Boolean(obj.isApprox || obj.estimated),
    source: obj.source || "json",
    sourceUrl: obj.sourceUrl || "",
    search: "".concat(name, " ").concat(code, " ").concat(family).toLowerCase()
  };
}
function prepareShadeList(list) {
  var deduped = [];
  var seen = new Set();
  list.forEach(function (shade, index) {
    var normalized = shade.rgb ? shade : normalizeShade(shade, index);
    if (!normalized) return;
    var key = "".concat(normalized.code, "|").concat(normalized.name, "|").concat(normalized.hex).toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    deduped.push(_objectSpread(_objectSpread({}, normalized), {}, {
      id: normalized.id || "".concat(slugify(normalized.code), "-").concat(index)
    }));
  });
  return deduped.sort(function (a, b) {
    var familyCompare = a.family.localeCompare(b.family);
    if (familyCompare !== 0) return familyCompare;
    return a.name.localeCompare(b.name);
  });
}
function extractHex(obj) {
  var direct = readAny(obj, ["hex", "hexCode", "hexcode", "shadeHex", "shadeHexCode", "shadeHexadecimalCode", "hexadecimal", "hexadecimalCode", "colorHex", "colourHex", "colorHexCode", "colourHexCode", "htmlColor", "htmlColour", "rgbHexCode", "rgbHex", "webHex", "swatchHex", "shadeRGB", "shadeRgb", "rgb", "rgbValue", "rgbCode", "rgbcode", "rgb_code", "shadeRGBValue", "shadeRgbValue", "colorRgb", "colourRgb", "colorRGB", "colourRGB", "shadeColor", "shadeColour", "background", "backgroundColor", "bgColor", "color", "colour", "value"]);
  if (Array.isArray(direct)) return rgbArrayToHex(direct);
  if (_typeof(direct) === "object" && direct) {
    var nestedHex = readAny(direct, ["hex", "hexCode", "value", "color", "colour"]);
    if (nestedHex) return nestedHex;
    if (["r", "g", "b"].every(function (key) {
      return key in direct;
    })) return rgbToHex(Number(direct.r), Number(direct.g), Number(direct.b));
    if (["red", "green", "blue"].every(function (key) {
      return key in direct;
    })) return rgbToHex(Number(direct.red), Number(direct.green), Number(direct.blue));
  }
  if (typeof direct === "string") {
    var _direct$match, _direct$match2, _direct$match3;
    if (/rgb\s*\(/i.test(direct)) return rgbStringToHex(direct);
    var numericTriple = direct.match(/^\s*(\d{1,3})\s*[,| ]\s*(\d{1,3})\s*[,| ]\s*(\d{1,3})\s*$/);
    if (numericTriple) return rgbToHex(Number(numericTriple[1]), Number(numericTriple[2]), Number(numericTriple[3]));
    var styleHex = (_direct$match = direct.match(/background(?:-color)?\s*:\s*(#[0-9a-f]{3,8}|rgba?\([^)]+\))/i)) === null || _direct$match === void 0 ? void 0 : _direct$match[1];
    if (styleHex) return /rgb\s*\(/i.test(styleHex) ? rgbStringToHex(styleHex) : styleHex;
    var embeddedHex = ((_direct$match2 = direct.match(/#[0-9a-f]{3}(?:[0-9a-f]{3})?\b/i)) === null || _direct$match2 === void 0 ? void 0 : _direct$match2[0]) || ((_direct$match3 = direct.match(/\b[0-9a-f]{6}\b/i)) === null || _direct$match3 === void 0 ? void 0 : _direct$match3[0]);
    return embeddedHex || direct;
  }
  var triples = [["r", "g", "b"], ["R", "G", "B"], ["red", "green", "blue"], ["Red", "Green", "Blue"], ["shadeR", "shadeG", "shadeB"], ["shadeRed", "shadeGreen", "shadeBlue"], ["redValue", "greenValue", "blueValue"], ["rValue", "gValue", "bValue"]];
  for (var _i = 0, _triples = triples; _i < _triples.length; _i++) {
    var _triples$_i = _slicedToArray(_triples[_i], 3),
      rk = _triples$_i[0],
      gk = _triples$_i[1],
      bk = _triples$_i[2];
    var r = readAny(obj, [rk]);
    var g = readAny(obj, [gk]);
    var b = readAny(obj, [bk]);
    if ([r, g, b].every(function (value) {
      return value !== null && value !== undefined && value !== "" && !Number.isNaN(Number(value));
    })) {
      return rgbToHex(Number(r), Number(g), Number(b));
    }
  }
  return null;
}
function readAny(obj, keys) {
  if (!obj || _typeof(obj) !== "object") return null;
  var _iterator = _createForOfIteratorHelper(keys),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var key = _step.value;
      if (Object.prototype.hasOwnProperty.call(obj, key) && obj[key] !== null && obj[key] !== undefined && obj[key] !== "") return obj[key];
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  var lowerMap = Object.keys(obj).reduce(function (acc, key) {
    acc[key.toLowerCase()] = key;
    return acc;
  }, {});
  var _iterator2 = _createForOfIteratorHelper(keys),
    _step2;
  try {
    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      var _key = _step2.value;
      var actual = lowerMap[_key.toLowerCase()];
      if (actual && obj[actual] !== null && obj[actual] !== undefined && obj[actual] !== "") return obj[actual];
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }
  return null;
}

// Builds colour-family chips from the API response; no family list is hardcoded in HTML.
function buildCategoryTabs() {
  var familyCounts = new Map();
  state.all.forEach(function (shade) {
    return familyCounts.set(shade.family, (familyCounts.get(shade.family) || 0) + 1);
  });
  var families = _toConsumableArray(familyCounts.entries()).sort(function (a, b) {
    return b[1] - a[1] || a[0].localeCompare(b[0]);
  }).map(function (_ref3) {
    var _ref4 = _slicedToArray(_ref3, 1),
      family = _ref4[0];
    return family;
  });
  var trendingFamilies = new Set(families.slice(0, 5));
  var tabs = ["All"].concat(_toConsumableArray(families)).map(function (family, index) {
    var count = index === 0 ? state.all.length : familyCounts.get(family);
    var accent = familyAccent(family);
    var soft = shiftColor(accent, 34, -12);
    var deep = shiftColor(accent, -12, 6);
    var classes = ["tab", index === 0 ? "active" : "", index > 0 && trendingFamilies.has(family) ? "trending" : ""].filter(Boolean).join(" ");
    return "<button class=\"".concat(classes, "\" type=\"button\" role=\"tab\" data-family=\"").concat(escapeAttr(family), "\" aria-selected=\"").concat(index === 0, "\" style=\"--tab-accent:").concat(accent, ";--tab-soft:").concat(soft, ";--tab-deep:").concat(deep, ";--tab-shadow:").concat(hexToRgba(accent, .24), "\">\n      <span class=\"tab-dot\" aria-hidden=\"true\"></span>\n      <span class=\"tab-label\">").concat(escapeHtml(family), "</span>\n      <em>").concat(count, "</em>\n    </button>");
  }).join("");
  dom.tabs.html(tabs);
  dom.tabs.off("click", ".tab").on("click", ".tab", function () {
    applyFilter($(this).data("family"));
  });
}
function applyFilter(family) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  state.category = family || "All";
  state.favoritesOnly = false;
  updateShortlistToggle();
  dom.tabs.find(".tab").removeClass("active").attr("aria-selected", "false");
  dom.tabs.find(".tab").filter(function (_, tab) {
    return $(tab).data("family") === state.category;
  }).addClass("active").attr("aria-selected", "true");
  state.filtered = state.category === "All" ? _toConsumableArray(state.all) : state.all.filter(function (shade) {
    return shade.family === state.category;
  });
  resetSelectionAfterFilter(options);
}
function toggleFavoritesFilter() {
  // The old button name was “Favorites”. It now behaves as a clearer
  // “Shortlisted” filter, using the same colours shown in the header CTA.
  state.favoritesOnly = !state.favoritesOnly;
  updateShortlistToggle();
  if (state.favoritesOnly) {
    var shortlistedIds = getShortlistedShadeIds();
    state.filtered = state.all.filter(function (shade) {
      return shortlistedIds.has(shade.id);
    });
    if (!state.filtered.length) {
      showToast("No shortlisted shades yet. Tap + on a fan strip or Save shade first.");
      state.favoritesOnly = false;
      updateShortlistToggle();
      applyFilter(state.category, {
        silent: true
      });
      return;
    }
    dom.tabs.find(".tab").removeClass("active").attr("aria-selected", "false");
    resetSelectionAfterFilter();
  } else {
    applyFilter(state.category, {
      silent: true
    });
  }
}
function resetSelectionAfterFilter() {
  var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  if (!state.filtered.length) {
    state.selectedIndex = 0;
    state.selectedId = null;
    renderDeck({
      animate: false
    });
    syncUi();
    return;
  }
  var preservedIndex = state.selectedId ? state.filtered.findIndex(function (shade) {
    return shade.id === state.selectedId;
  }) : -1;
  state.selectedIndex = preservedIndex >= 0 ? preservedIndex : 0;
  state.selectedId = state.filtered[state.selectedIndex].id;
  dom.range.attr({
    min: 0,
    max: Math.max(0, state.filtered.length - 1)
  });
  renderDeck({
    animate: !options.silent
  });
  syncUi();
}
function setSelectedIndex(index) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (!state.filtered.length) return;
  var nextIndex = clamp(Math.round(index), 0, state.filtered.length - 1);
  if (nextIndex === state.selectedIndex && options.source !== "force") {
    syncUi();
    return;
  }
  state.selectedIndex = nextIndex;
  state.selectedId = state.filtered[nextIndex].id;
  var animate = !["range", "scroll", "drag", "touch-swipe"].includes(options.source);
  renderDeck({
    animate: animate
  });
  syncUi();
}
function selectById(id) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (!id) return;
  var index = state.filtered.findIndex(function (shade) {
    return shade.id === id;
  });
  var shade = state.all.find(function (item) {
    return item.id === id;
  });
  if (index < 0 && shade) {
    if (state.favoritesOnly) toggleFavoritesFilter();
    if (state.category !== "All" && shade.family !== state.category) {
      applyFilter(shade.family, {
        silent: true
      });
    }
    index = state.filtered.findIndex(function (item) {
      return item.id === id;
    });
  }
  if (index >= 0) {
    setSelectedIndex(index, {
      source: options.source || "select"
    });
    if (options.open) openModal(getSelectedShade());
  }
}
function stepShade(step) {
  setSelectedIndex(state.selectedIndex + step, {
    source: "step"
  });
}
function renderDeck() {
  var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var shades = state.filtered;
  var selectedShade = getSelectedShade();
  if (!shades.length) {
    state.deckWindow = {
      key: "",
      start: 0,
      end: 0
    };
    dom.fanDeck.html("<div class=\"empty-tray\">No shades available from the API</div>");
    return;
  }
  var maxCards = window.matchMedia("(max-width: 820px)").matches ? MAX_CARDS_MOBILE : MAX_CARDS_DESKTOP;
  var visibleCount = Math.min(maxCards, shades.length);
  var windowKey = deckWindowKey(shades, visibleCount);
  var _computeDeckWindow = computeDeckWindow(shades, visibleCount, windowKey),
    start = _computeDeckWindow.start,
    end = _computeDeckWindow.end;
  var centerSlot = state.selectedIndex - start;
  var maxSpread = window.matchMedia("(max-width: 820px)").matches ? 58 : 63;
  var gap = visibleCount > 1 ? Math.min(6.2, maxSpread * 2 / Math.max(1, visibleCount - 1)) : 0;
  var sameWindow = !options.force && state.deckWindow.key === windowKey && state.deckWindow.start === start && state.deckWindow.end === end && dom.fanDeck.find(".fan-card").length === end - start;

  // For mobile swipes, updating existing DOM nodes avoids the blink caused by
  // deleting/recreating 30+ cards on every shade step.
  if (sameWindow) {
    updateDeckCardStates({
      shades: shades,
      start: start,
      end: end,
      centerSlot: centerSlot,
      gap: gap,
      selectedShade: selectedShade,
      animate: options.animate !== false
    });
    return;
  }
  var html = [];
  for (var slot = 0; slot < end - start; slot += 1) {
    html.push(fanCardMarkup(shades[start + slot], slot, {
      start: start,
      centerSlot: centerSlot,
      gap: gap,
      selectedShade: selectedShade
    }));
  }
  dom.fanDeck.html(html.join(""));
  state.deckWindow = {
    key: windowKey,
    start: start,
    end: end
  };
  animateDeckSpin(options.animate !== false);
  if (window.gsap && options.animate !== false && !state.isDragging) {
    gsap.fromTo(dom.fanDeck.find(".fan-card"), {
      y: 18,
      opacity: 0.75
    }, {
      y: 0,
      opacity: 1,
      duration: 0.42,
      ease: "power3.out",
      stagger: {
        each: 0.006,
        from: "center"
      }
    });
  }
}
function fanCardMarkup(shade, slot, context) {
  var start = context.start,
    centerSlot = context.centerSlot,
    gap = context.gap,
    selectedShade = context.selectedShade;
  var rel = slot - centerSlot;
  var angle = rel * gap;
  var isActive = shade.id === (selectedShade === null || selectedShade === void 0 ? void 0 : selectedShade.id);
  var isFavorite = state.favorites.has(shade.id);
  var isShortlisted = isShadeShortlisted(shade);
  var lift = isActive ? -20 : Math.max(-9, -Math.abs(rel) * 0.16);
  var z = 300 - Math.abs(rel);
  var tintA = shiftColor(shade.hex, 17, 6);
  var tintB = shiftColor(shade.hex, 10, 3);
  var tintC = shade.hex;
  var tintD = shiftColor(shade.hex, -8, -2);
  return "\n    <button class=\"fan-card".concat(isActive ? " active" : "").concat(isFavorite ? " favorite" : "").concat(isShortlisted ? " shortlisted" : "", "\" type=\"button\"\n      data-id=\"").concat(escapeAttr(shade.id), "\"\n      data-slot=\"").concat(start + slot, "\"\n      title=\"").concat(escapeAttr("".concat(shade.name, " ").concat(shade.code)), "\"\n      style=\"--angle:").concat(angle.toFixed(3), "deg;--lift:").concat(lift, "px;--card-bg:").concat(shade.hex, ";z-index:").concat(z, ";\">\n      <span class=\"card-fav\" aria-label=\"Shortlist ").concat(escapeAttr(shade.name), "\"><i class=\"").concat(isShortlisted ? "ri-check-line" : "ri-add-line", "\"></i></span>\n      <div class=\"card-cap\" data-hex=\"").concat(escapeAttr(tintA), "\" data-role=\"Light top\" data-label=\"").concat(escapeAttr("".concat(shade.name, " Light Top")), "\" style=\"background:").concat(tintA, "\"><span class=\"strip-code\">").concat(escapeHtml(shade.code), "</span><span class=\"strip-add\" aria-hidden=\"true\">+</span></div>\n      <div class=\"card-strip\" data-hex=\"").concat(escapeAttr(tintA), "\" data-role=\"Soft tint\" data-label=\"").concat(escapeAttr("".concat(shade.name, " Soft Tint")), "\" style=\"background:").concat(tintA, "\"><span class=\"strip-code\">").concat(escapeHtml(shortCode(shade.code, 0)), "</span><span class=\"strip-add\" aria-hidden=\"true\">+</span></div>\n      <div class=\"card-strip\" data-hex=\"").concat(escapeAttr(tintB), "\" data-role=\"Wall tone\" data-label=\"").concat(escapeAttr("".concat(shade.name, " Wall Tone")), "\" style=\"background:").concat(tintB, "\"><span class=\"strip-code\">").concat(escapeHtml(shortCode(shade.code, 1)), "</span><span class=\"strip-add\" aria-hidden=\"true\">+</span></div>\n      <div class=\"card-strip\" data-hex=\"").concat(escapeAttr(tintC), "\" data-role=\"Primary\" data-label=\"").concat(escapeAttr(shade.name), "\" style=\"background:").concat(tintC, "\"><span class=\"strip-code\">").concat(escapeHtml(shortCode(shade.code, 2)), "</span><span class=\"strip-add\" aria-hidden=\"true\">+</span></div>\n      <div class=\"card-strip\" data-hex=\"").concat(escapeAttr(tintD), "\" data-role=\"Deep accent\" data-label=\"").concat(escapeAttr("".concat(shade.name, " Deep Accent")), "\" style=\"background:").concat(tintD, "\"><span class=\"strip-code\">").concat(escapeHtml(shortCode(shade.code, 3)), "</span><span class=\"strip-add\" aria-hidden=\"true\">+</span></div>\n      <span class=\"card-name\">").concat(escapeHtml(shade.name), "</span>\n    </button>");
}
function updateDeckCardStates(_ref5) {
  var shades = _ref5.shades,
    start = _ref5.start,
    end = _ref5.end,
    centerSlot = _ref5.centerSlot,
    gap = _ref5.gap,
    selectedShade = _ref5.selectedShade,
    animate = _ref5.animate;
  dom.fanDeck.find(".fan-card").each(function (slot) {
    var shade = shades[start + slot];
    if (!shade) return;
    var rel = slot - centerSlot;
    var angle = rel * gap;
    var isActive = shade.id === (selectedShade === null || selectedShade === void 0 ? void 0 : selectedShade.id);
    var isFavorite = state.favorites.has(shade.id);
    var isShortlisted = isShadeShortlisted(shade);
    var lift = isActive ? -20 : Math.max(-9, -Math.abs(rel) * 0.16);
    var z = 300 - Math.abs(rel);
    this.style.setProperty("--angle", "".concat(angle.toFixed(3), "deg"));
    this.style.setProperty("--lift", "".concat(lift, "px"));
    this.style.zIndex = String(z);
    $(this).toggleClass("active", isActive).toggleClass("favorite", isFavorite).toggleClass("shortlisted", isShortlisted).attr("title", "".concat(shade.name, " ").concat(shade.code)).find(".card-fav i").attr("class", isShortlisted ? "ri-check-line" : "ri-add-line");
  });
  animateDeckSpin(animate && !state.isDragging);
}
function animateDeckSpin() {
  var animate = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
  var shades = state.filtered;
  var spin = state.selectedIndex / Math.max(1, shades.length - 1) * -10 + 5;
  if (window.gsap) {
    gsap.to(dom.fanDeck[0], {
      "--deck-spin": "".concat(spin, "deg"),
      duration: animate ? 0.35 : 0,
      ease: "power3.out"
    });
  } else {
    dom.fanDeck.css("--deck-spin", "".concat(spin, "deg"));
  }
}
function deckWindowKey(shades, visibleCount) {
  var _shades$, _shades;
  return [state.category, state.favoritesOnly ? "fav" : "all", visibleCount, shades.length, ((_shades$ = shades[0]) === null || _shades$ === void 0 ? void 0 : _shades$.id) || "", ((_shades = shades[shades.length - 1]) === null || _shades === void 0 ? void 0 : _shades.id) || ""].join("|");
}
function computeDeckWindow(shades, visibleCount, windowKey) {
  var maxStart = Math.max(0, shades.length - visibleCount);
  var old = state.deckWindow || {
    key: "",
    start: 0,
    end: 0
  };
  var buffer = window.matchMedia("(max-width: 820px)").matches ? 5 : 8;
  if (old.key === windowKey && old.end - old.start === visibleCount) {
    var insideBufferedWindow = state.selectedIndex >= old.start + buffer && state.selectedIndex < old.end - buffer;
    if (insideBufferedWindow) return {
      start: old.start,
      end: old.end
    };
  }
  var half = Math.floor(visibleCount / 2);
  var start = clamp(state.selectedIndex - half, 0, maxStart);
  var end = Math.min(start + visibleCount, shades.length);
  start = Math.max(0, end - visibleCount);
  return {
    start: start,
    end: end
  };
}
function syncUi() {
  var shade = getSelectedShade();
  var total = state.filtered.length;
  var index = total ? state.selectedIndex + 1 : 0;
  var progress = total > 1 ? state.selectedIndex / (total - 1) : 0;
  dom.range.attr({
    min: 0,
    max: Math.max(0, total - 1)
  }).val(state.selectedIndex);
  dom.rangeCount.text("".concat(index, " / ").concat(total));
  dom.progressText.text(shade ? "".concat(shade.name, " \xB7 ").concat(shade.code) : "No shade selected");
  dom.shadeTotal.text("".concat(total, " shade").concat(total === 1 ? "" : "s"));
  dom.progressFill.css("width", "".concat(progress * 100, "%"));
  dom.progressKnob.css("left", "".concat(progress * 100, "%"));
  renderSelectedPalette();
  if (!shade) return;
  var textColor = readableText(shade.hex);
  dom.beaconSwatch.css("background", shade.hex);
  dom.beaconName.text(shade.name);
  dom.beaconMeta.text("".concat(shade.family, " \xB7 ").concat(shade.code, " \xB7 ").concat(shade.hex.toUpperCase()));
  dom.activeFamily.text(shade.family);
  dom.activeName.text(shade.name);
  dom.activeCode.text("Shade code ".concat(shade.code));
  dom.activeHex.text(shade.hex.toUpperCase());
  dom.activeRgb.text(shade.rgbText);
  dom.previewWall.css("--preview-color", shade.hex);
  var shadeShortlisted = isShadeShortlisted(shade);
  dom.favoriteCurrent.toggleClass("active", shadeShortlisted).attr("aria-label", shadeShortlisted ? "Colour already shortlisted" : "Shortlist selected colour").find("i").attr("class", shadeShortlisted ? "ri-check-line" : "ri-add-line");
  dom.selectedBeacon.css({
    color: textColor === "#ffffff" ? "#0f172a" : "#0f172a"
  });
}
function openModal(shade) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (!shade) return;
  closeSelectionModal({
    instant: true
  });
  var modalColour = normalizeModalColour(options.sample || shade);
  state.currentModalColor = modalColour;
  dom.overlay.css("--modal-color", modalColour.hex);
  dom.overlay.find(".shade-modal").css("--modal-color", modalColour.hex);
  dom.modalSwatch.css("--modal-color", modalColour.hex);
  dom.modalFamily.text(modalColour.sampleRole ? "".concat(modalColour.family, " \xB7 ").concat(modalColour.sampleRole) : modalColour.family);
  dom.modalShadeName.text(modalColour.name);
  dom.modalShadeCode.text("Shade code ".concat(modalColour.code));
  dom.modalHex.text(modalColour.hex.toUpperCase());
  dom.modalRgb.text(modalColour.rgbText);
  dom.modalCode.text(modalColour.code);
  updateModalShortlistState(modalColour);
  buildSmartPalette(modalColour);
  renderSelectedPalette();
  dom.body.addClass("modal-open");
  dom.overlay.addClass("active").attr("aria-hidden", "false");
  var modalNode = dom.overlay.find(".shade-modal")[0];
  var modalContentNode = dom.overlay.find(".modal-content")[0];
  if (modalNode) modalNode.scrollTop = 0;
  if (modalContentNode) modalContentNode.scrollTop = 0;

  // On real phones, transform-based entrance animations can briefly flash while
  // the browser promotes a large blurred modal layer. Keep the first paint stable
  // on small/touch screens and animate only on larger screens.
  if (prefersStableModal() || !window.gsap) {
    if (modalNode) {
      modalNode.style.opacity = "";
      modalNode.style.transform = "";
    }
    return;
  }
  gsap.killTweensOf(modalNode);
  gsap.fromTo(modalNode, {
    y: 18,
    scale: .985,
    opacity: 0
  }, {
    y: 0,
    scale: 1,
    opacity: 1,
    duration: .24,
    ease: "power2.out"
  });
}
function normalizeModalColour(colour) {
  var hex = normalizeHex(colour === null || colour === void 0 ? void 0 : colour.hex) || "#ffffff";
  var rgb = (colour === null || colour === void 0 ? void 0 : colour.rgb) || hexToRgb(hex);
  return _objectSpread(_objectSpread({}, colour), {}, {
    hex: hex,
    rgb: rgb,
    rgbText: (colour === null || colour === void 0 ? void 0 : colour.rgbText) || "".concat(rgb.r, ", ").concat(rgb.g, ", ").concat(rgb.b),
    family: cleanText(colour === null || colour === void 0 ? void 0 : colour.family) || "Colour",
    name: cleanText(colour === null || colour === void 0 ? void 0 : colour.name) || "Selected colour",
    code: cleanText(colour === null || colour === void 0 ? void 0 : colour.code) || "Custom",
    sampleRole: cleanText(colour === null || colour === void 0 ? void 0 : colour.sampleRole) || "",
    baseShadeId: (colour === null || colour === void 0 ? void 0 : colour.baseShadeId) || (colour === null || colour === void 0 ? void 0 : colour.shadeId) || (colour === null || colour === void 0 ? void 0 : colour.id) || null
  });
}
function prefersStableModal() {
  return window.matchMedia("(max-width: 820px), (pointer: coarse), (prefers-reduced-motion: reduce)").matches;
}
function closeModal() {
  if (!dom.overlay.hasClass("active")) return;
  var modalNode = dom.overlay.find(".shade-modal")[0];
  var complete = function complete() {
    dom.overlay.removeClass("active").attr("aria-hidden", "true");
    state.currentModalColor = null;
    if (modalNode) {
      modalNode.style.opacity = "";
      modalNode.style.transform = "";
    }
    if (!dom.selectionOverlay.hasClass("active")) dom.body.removeClass("modal-open");
  };
  if (prefersStableModal() || !window.gsap) {
    complete();
    return;
  }
  gsap.killTweensOf(modalNode);
  gsap.to(modalNode, {
    y: 14,
    scale: .99,
    opacity: 0,
    duration: .16,
    ease: "power2.in",
    onComplete: complete
  });
}
function openSelectionModal() {
  renderSelectedPalette();
  closeModal();
  dom.body.addClass("modal-open");
  dom.selectionOverlay.addClass("active").attr("aria-hidden", "false");
  var selectionNode = dom.selectionOverlay.find(".selection-modal")[0];
  if (selectionNode) selectionNode.scrollTop = 0;
  if (window.gsap) {
    gsap.fromTo(".selection-modal", {
      y: 24,
      scale: .97,
      opacity: 0
    }, {
      y: 0,
      scale: 1,
      opacity: 1,
      duration: .34,
      ease: "power3.out"
    });
  }
}
function closeSelectionModal() {
  var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  if (!dom.selectionOverlay.hasClass("active")) return;
  var complete = function complete() {
    dom.selectionOverlay.removeClass("active").attr("aria-hidden", "true");
    if (!dom.overlay.hasClass("active")) dom.body.removeClass("modal-open");
  };
  if (options.instant || !window.gsap) {
    complete();
    return;
  }
  gsap.to(".selection-modal", {
    y: 18,
    scale: .98,
    opacity: 0,
    duration: .2,
    ease: "power2.in",
    onComplete: complete
  });
}
function shortlistShade(shade, origin) {
  if (!shade) return;
  var role = shade.sampleRole || "Shortlisted shade";
  var source = shade.isSample ? "Details popup sample" : "Fan plus";
  savePaletteColor(shadeToPaletteItem(shade, {
    role: role,
    source: source
  }), {
    origin: origin,
    toast: function toast(colour, added) {
      return added ? "Shortlisted colour: ".concat(colour.name, ".") : "".concat(colour.name, " is already shortlisted and moved to the front.");
    }
  });
}
function isShadeShortlisted(shade) {
  if (!shade) return false;
  var baseId = shade.baseShadeId || shade.shadeId || shade.id;
  var exactKey = shade.key || paletteKey(shadeToPaletteItem(shade) || shade);
  return state.selectedPalette.some(function (item) {
    return item.key === exactKey || item.hex === shade.hex || item.shadeId === baseId && !shade.isSample;
  });
}
function updateModalShortlistState(shade) {
  var _dom$modalFavorite;
  if (!shade || !((_dom$modalFavorite = dom.modalFavorite) !== null && _dom$modalFavorite !== void 0 && _dom$modalFavorite.length)) return;
  var shortlisted = isShadeShortlisted(shade);
  dom.modalFavorite.toggleClass("saved", shortlisted).html("<i class=\"".concat(shortlisted ? "ri-check-line" : "ri-add-line", "\" aria-hidden=\"true\"></i> ").concat(shortlisted ? "Shortlisted" : "Shortlist shade"));
}

// Smart palette derives companion colours from the selected API shade.
function buildSmartPalette(shade) {
  if (!shade) {
    state.currentSmartPalette = [];
    dom.smartPalette.empty();
    return;
  }
  var base = shade.hex;
  var palette = [shadeToPaletteItem(shade, {
    role: "Primary",
    source: "Selected shade",
    hex: base,
    name: shade.name,
    featured: true
  }), shadeToPaletteItem(shade, {
    role: "Soft wall",
    source: "Smart palette",
    hex: shiftColor(base, 24, -8),
    name: "".concat(shade.name, " Mist"),
    wide: true
  }), shadeToPaletteItem(shade, {
    role: "Warm accent",
    source: "Smart palette",
    hex: shiftHue(base, 38, 5, 4),
    name: "".concat(shade.name, " Warm Accent")
  }), shadeToPaletteItem(shade, {
    role: "Cool contrast",
    source: "Smart palette",
    hex: shiftHue(base, 182, -1, -5),
    name: "".concat(shade.name, " Contrast")
  }), shadeToPaletteItem(shade, {
    role: "Deep trim",
    source: "Smart palette",
    hex: shiftColor(base, -18, 5),
    name: "".concat(shade.name, " Deep Trim"),
    wide: true
  })].map(function (item) {
    return _objectSpread(_objectSpread({}, item), {}, {
      key: paletteKey(item)
    });
  });
  state.currentSmartPalette = palette;
  dom.smartPalette.html(palette.map(function (item, index) {
    var text = readableText(item.hex);
    var ratio = contrastRatio(item.hex, text);
    var saved = hasPaletteColor(item.key) || hasPaletteColor(item.hex);
    var classes = ["palette-tile", item.featured ? "featured" : "", item.wide ? "wide" : "", saved ? "saved" : ""].filter(Boolean).join(" ");
    return "<button class=\"".concat(classes, "\" type=\"button\" data-key=\"").concat(escapeAttr(item.key), "\" style=\"--tile-bg:").concat(item.hex, ";--tile-text:").concat(text, ";\" title=\"Save ").concat(escapeAttr(item.name), "\">\n      <span class=\"tile-top\">\n        <span class=\"tile-copy\">\n          <span class=\"tile-role\">").concat(escapeHtml(item.role), "</span>\n          <span class=\"tile-name\">").concat(escapeHtml(item.name), "</span>\n        </span>\n        <span class=\"contrast-pill\">").concat(contrastGrade(ratio), " ").concat(ratio.toFixed(1), "</span>\n      </span>\n      <span class=\"tile-bottom\">\n        <span class=\"tile-meta\">").concat(escapeHtml(item.hex.toUpperCase()), "</span>\n        <span class=\"tile-save\"><i class=\"").concat(saved ? "ri-check-line" : "ri-heart-3-line", "\" aria-hidden=\"true\"></i>").concat(saved ? "Saved" : "Save", "</span>\n      </span>\n    </button>");
  }).join(""));
  dom.smartPalette.off("click", ".palette-tile").on("click", ".palette-tile", function () {
    var key = String($(this).data("key"));
    var item = state.currentSmartPalette.find(function (color) {
      return color.key === key;
    });
    if (!item) return;
    savePaletteColor(item, {
      origin: this,
      toast: function toast(colour, added) {
        return added ? "Shortlisted colour: ".concat(colour.name, ".") : "".concat(colour.name, " is already shortlisted and moved to the front.");
      }
    });
  });
}
function toggleFavorite(shade) {
  if (!shade) return;
  var willSave = !state.favorites.has(shade.id);
  if (willSave) {
    state.favorites.add(shade.id);
    savePaletteColor(shadeToPaletteItem(shade, {
      role: "Favourite shade",
      source: "Heart"
    }), {
      silent: true
    });
    showToast("".concat(shade.name, " saved."));
  } else {
    state.favorites["delete"](shade.id);
    showToast("".concat(shade.name, " removed from favourites."));
  }
  haptic();
  persistFavorites();
  renderDeck({
    animate: false
  });
  syncUi();
  if (dom.overlay.hasClass("active")) openModal(getSelectedShade());
}
function loadFavorites() {
  try {
    var stored = JSON.parse(localStorage.getItem(FAVORITE_KEY) || "[]");
    state.favorites = new Set(Array.isArray(stored) ? stored : []);
  } catch (_) {
    state.favorites = new Set();
  }
}
function persistFavorites() {
  localStorage.setItem(FAVORITE_KEY, JSON.stringify(_toConsumableArray(state.favorites)));
}
function loadSelectedPalette() {
  try {
    var stored = JSON.parse(localStorage.getItem(PALETTE_KEY) || "[]");
    state.selectedPalette = Array.isArray(stored) ? stored.map(function (item) {
      return normalizePaletteItem(item);
    }).filter(Boolean).slice(0, MAX_SELECTION) : [];
  } catch (_) {
    state.selectedPalette = [];
  }
}
function persistSelectedPalette() {
  localStorage.setItem(PALETTE_KEY, JSON.stringify(state.selectedPalette));
}
function shadeToPaletteItem(shade) {
  var overrides = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (!shade) return null;
  var hex = normalizeHex(overrides.hex || shade.hex) || shade.hex;
  return normalizePaletteItem({
    // For generated fan-strip samples, keep the API shade id so the selection
    // popup can still jump back to the original fandeck card.
    shadeId: overrides.shadeId || shade.baseShadeId || shade.shadeId || shade.id,
    name: overrides.name || shade.name,
    code: overrides.code || shade.code,
    family: overrides.family || shade.family,
    role: overrides.role || shade.sampleRole || "Shade",
    source: overrides.source || shade.source || "Fandeck",
    hex: hex,
    featured: Boolean(overrides.featured),
    wide: Boolean(overrides.wide)
  });
}
function paletteItemFromElement(shade, element) {
  var target = $(element);
  var hex = normalizeHex(target.data("hex")) || shade.hex;
  var role = cleanText(target.data("role")) || "Sample";
  var name = cleanText(target.data("label")) || "".concat(shade.name, " ").concat(role);
  return shadeToPaletteItem(shade, {
    hex: hex,
    role: role,
    name: name,
    source: "Fan strip"
  });
}

// Builds a modal-ready colour object for the exact fan cap/strip clicked.
// The API gives one main shade colour per card; each cap/strip is a generated
// physical fandeck-style sample. This helper makes those samples first-class
// enough for the details popup, copy chips, smart palette, and shortlist button.
function shadeSampleFromElement(shade, element) {
  var sample = paletteItemFromElement(shade, element);
  if (!sample) return shade;
  var rgb = hexToRgb(sample.hex);
  return _objectSpread(_objectSpread({}, shade), {}, {
    id: "".concat(shade.id, "--").concat(slugify(sample.role), "--").concat(sample.hex.replace("#", "")),
    baseShadeId: shade.id,
    shadeId: shade.id,
    name: sample.name,
    code: sample.code,
    family: sample.family,
    sampleRole: sample.role,
    source: sample.source,
    hex: sample.hex,
    rgb: rgb,
    rgbText: "".concat(rgb.r, ", ").concat(rgb.g, ", ").concat(rgb.b),
    hsl: rgbToHsl(rgb.r, rgb.g, rgb.b),
    isSample: true,
    key: sample.key,
    search: "".concat(sample.name, " ").concat(sample.code, " ").concat(sample.family, " ").concat(sample.role).toLowerCase()
  });
}
function normalizePaletteItem(item) {
  if (!item || !item.hex) return null;
  var hex = normalizeHex(item.hex);
  if (!hex) return null;
  var safe = {
    shadeId: item.shadeId || item.id || null,
    name: cleanText(item.name) || "Selected colour",
    code: cleanText(item.code) || "Custom",
    family: cleanText(item.family) || "Palette",
    role: cleanText(item.role) || "Sample",
    source: cleanText(item.source) || "Palette",
    hex: hex,
    featured: Boolean(item.featured),
    wide: Boolean(item.wide)
  };
  safe.key = item.key || paletteKey(safe);
  return safe;
}
function paletteKey(item) {
  var _normalizeHex;
  return "".concat(slugify(item.shadeId || item.code || item.name), "-").concat(((_normalizeHex = normalizeHex(item.hex)) === null || _normalizeHex === void 0 ? void 0 : _normalizeHex.replace("#", "")) || "colour", "-").concat(slugify(item.role || "sample"));
}
function hasPaletteColor(keyOrHex) {
  var normalizedHex = normalizeHex(keyOrHex);
  return state.selectedPalette.some(function (item) {
    return normalizedHex ? item.hex === normalizedHex : item.key === keyOrHex;
  });
}
function getModalPaletteBase() {
  var _dom$overlay;
  return (_dom$overlay = dom.overlay) !== null && _dom$overlay !== void 0 && _dom$overlay.hasClass("active") && state.currentModalColor ? state.currentModalColor : getSelectedShade();
}
function savePaletteColor(item) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var normalized = normalizePaletteItem(item);
  if (!normalized) return;
  var existingIndex = state.selectedPalette.findIndex(function (color) {
    return color.key === normalized.key || color.hex === normalized.hex;
  });
  var added = false;
  if (existingIndex >= 0) {
    state.selectedPalette.splice(existingIndex, 1);
    state.selectedPalette.unshift(normalized);
  } else {
    state.selectedPalette.unshift(normalized);
    added = true;
    if (state.selectedPalette.length > MAX_SELECTION) state.selectedPalette.length = MAX_SELECTION;
  }
  persistSelectedPalette();
  renderSelectedPalette();
  buildSmartPalette(getModalPaletteBase());
  if (!options.silent) {
    var customToast = typeof options.toast === "function" ? options.toast(normalized, added) : options.toast;
    showToast(customToast || (added ? "Shortlisted colour: ".concat(normalized.name, ".") : "".concat(normalized.name, " moved to the top of your shortlist.")));
  }
  haptic();
  animateSaved(options.origin);
  var savedTile = dom.smartPalette.find("[data-key=\"".concat(cssEscape(normalized.key), "\"]"));
  if (savedTile.length) animateSaved(savedTile[0]);
  updateModalShortlistState(getModalPaletteBase());
  setTimeout(function () {
    return renderDeck({
      animate: false
    });
  }, 180);
  if (options.open) openModal(getSelectedShade());
}
function removePaletteColor(key) {
  var before = state.selectedPalette.length;
  state.selectedPalette = state.selectedPalette.filter(function (item) {
    return item.key !== key;
  });
  if (state.selectedPalette.length === before) return;
  persistSelectedPalette();
  renderSelectedPalette();
  buildSmartPalette(getModalPaletteBase());
  renderDeck({
    animate: false
  });
  updateModalShortlistState(getModalPaletteBase());
  showToast("Colour removed from selection.");
}
function clearSelectedPalette() {
  if (!state.selectedPalette.length) return;
  state.selectedPalette = [];
  persistSelectedPalette();
  renderSelectedPalette();
  buildSmartPalette(getModalPaletteBase());
  renderDeck({
    animate: false
  });
  updateModalShortlistState(getModalPaletteBase());
  showToast("Colour selection cleared.");
}

// Renders the shortlisted colours in both the small tray and the header CTA modal.
function getShortlistedShadeIds() {
  return new Set(state.selectedPalette.map(function (item) {
    return item.shadeId;
  }).filter(Boolean));
}
function updateShortlistToggle() {
  var _dom$toggleFavorites;
  if (!((_dom$toggleFavorites = dom.toggleFavorites) !== null && _dom$toggleFavorites !== void 0 && _dom$toggleFavorites.length)) return;
  var count = getShortlistedShadeIds().size;
  var label = state.favoritesOnly ? "Showing shortlisted" : "Shortlisted";
  dom.toggleFavorites.toggleClass("active", state.favoritesOnly).attr("aria-label", state.favoritesOnly ? "Show all shades" : "Show only shortlisted shades").html("<i class=\"".concat(state.favoritesOnly ? "ri-bookmark-3-fill" : "ri-bookmark-3-line", "\" aria-hidden=\"true\"></i> ").concat(label).concat(count ? " <span class=\"pill-count\">".concat(count, "</span>") : ""));
}
function renderSelectedPalette() {
  var _dom$selectionCount, _dom$clearSelection, _dom$paletteHint, _dom$selectionBadge, _dom$selectionBento, _dom$selectionBento2, _dom$favoriteTray;
  var count = state.selectedPalette.length;
  var countText = "".concat(count, " colour").concat(count === 1 ? "" : "s");
  if ((_dom$selectionCount = dom.selectionCount) !== null && _dom$selectionCount !== void 0 && _dom$selectionCount.length) dom.selectionCount.text(countText);
  if ((_dom$clearSelection = dom.clearSelection) !== null && _dom$clearSelection !== void 0 && _dom$clearSelection.length) dom.clearSelection.prop("disabled", count === 0);
  if ((_dom$paletteHint = dom.paletteHint) !== null && _dom$paletteHint !== void 0 && _dom$paletteHint.length) {
    dom.paletteHint.text(count ? "".concat(countText, " shortlisted. Tap the blue header CTA to review.") : "Tap the + on a fan card, Save shade, or a smart palette tile to shortlist colours.");
  }
  if ((_dom$selectionBadge = dom.selectionBadge) !== null && _dom$selectionBadge !== void 0 && _dom$selectionBadge.length) {
    dom.selectionBadge.text(count).toggleClass("hidden", count === 0).addClass("bump");
    clearTimeout(renderSelectedPalette.badgeTimer);
    renderSelectedPalette.badgeTimer = setTimeout(function () {
      return dom.selectionBadge.removeClass("bump");
    }, 520);
  }
  var selectionPanel = (_dom$selectionBento = dom.selectionBento) === null || _dom$selectionBento === void 0 ? void 0 : _dom$selectionBento.closest(".selection-preview");
  if (selectionPanel !== null && selectionPanel !== void 0 && selectionPanel.length) selectionPanel.toggleClass("has-selection", count > 0);
  if ((_dom$selectionBento2 = dom.selectionBento) !== null && _dom$selectionBento2 !== void 0 && _dom$selectionBento2.length) {
    if (!count) {
      dom.selectionBento.html("<div class=\"empty-selection\">No colours shortlisted yet. Tap the + on a fandeck card or a smart palette tile.</div>");
    } else {
      dom.selectionBento.html(state.selectedPalette.map(function (item, index) {
        return selectionCardMarkup(item, index);
      }).join(""));
    }
  }
  if ((_dom$favoriteTray = dom.favoriteTray) !== null && _dom$favoriteTray !== void 0 && _dom$favoriteTray.length) {
    if (!count) {
      dom.favoriteTray.html("<span class=\"empty-tray\">No colours shortlisted yet</span>");
    } else {
      var minis = state.selectedPalette.slice(0, 4).map(function (item) {
        return "\n        <button class=\"selection-mini\" type=\"button\" data-shade-id=\"".concat(escapeAttr(item.shadeId || ""), "\" title=\"").concat(escapeAttr("".concat(item.name, " ").concat(item.hex.toUpperCase())), "\">\n          <span class=\"selection-mini-swatch\" style=\"background:").concat(item.hex, "\"></span>\n          <span class=\"selection-mini-text\"><strong>").concat(escapeHtml(item.name), "</strong><small>").concat(escapeHtml(item.hex.toUpperCase()), "</small></span>\n          <i class=\"ri-arrow-right-up-line\" aria-hidden=\"true\"></i>\n        </button>\n      ");
      }).join("");
      dom.favoriteTray.html("".concat(minis, "<button class=\"review-selection\" type=\"button\"><i class=\"ri-check-double-line\" aria-hidden=\"true\"></i> Review ").concat(count, "</button>"));
    }
  }
  updateShortlistToggle();
}
function selectionCardMarkup(item, index) {
  var text = readableText(item.hex);
  var ratio = contrastRatio(item.hex, text);
  var classes = ["selection-card", index === 0 ? "primary" : ""].filter(Boolean).join(" ");
  return "<article class=\"".concat(classes, "\" data-shade-id=\"").concat(escapeAttr(item.shadeId || ""), "\" style=\"--tile-bg:").concat(item.hex, ";--tile-text:").concat(text, ";\">\n    <button class=\"remove-selection\" type=\"button\" data-key=\"").concat(escapeAttr(item.key), "\" aria-label=\"Remove ").concat(escapeAttr(item.name), "\"><i class=\"ri-subtract-line\" aria-hidden=\"true\"></i></button>\n    <div>\n      <span class=\"tile-role\">").concat(escapeHtml(item.role), "</span>\n      <h3>").concat(escapeHtml(item.name), "</h3>\n      <p>").concat(escapeHtml(item.code), " \xB7 ").concat(escapeHtml(item.hex.toUpperCase()), "</p>\n    </div>\n    <span class=\"contrast-pill\">").concat(contrastGrade(ratio), " contrast \xB7 ").concat(ratio.toFixed(1), ":1</span>\n  </article>");
}
function animateSaved(origin) {
  var _dom$openDetails;
  if (origin) {
    var node = $(origin);
    node.addClass("just-saved saved-pulse");
    setTimeout(function () {
      return node.removeClass("just-saved saved-pulse");
    }, 650);
  }
  if (window.gsap && (_dom$openDetails = dom.openDetails) !== null && _dom$openDetails !== void 0 && _dom$openDetails.length) {
    gsap.fromTo(dom.openDetails[0], {
      scale: .92
    }, {
      scale: 1,
      duration: .42,
      ease: "elastic.out(1, .5)"
    });
  }
}
function haptic() {
  if (navigator.vibrate) navigator.vibrate(18);
}
function handleSearchInput() {
  var query = dom.search.val().trim().toLowerCase();
  state.lastQuery = query;
  dom.clearSearch.toggleClass("hidden", !query);
  if (!query) {
    dom.suggestions.hide().empty();
    return;
  }
  var matches = state.all.filter(function (shade) {
    return shade.search.includes(query);
  }).slice(0, 9);
  if (!matches.length) {
    dom.suggestions.html("<div class=\"suggestion-item\"><span></span><strong>No shade found</strong><small>Try a family, colour name, or code.</small></div>").show();
    return;
  }
  dom.suggestions.html(matches.map(function (shade) {
    return "\n    <button class=\"suggestion-item\" type=\"button\" data-id=\"".concat(escapeAttr(shade.id), "\">\n      <span class=\"suggestion-swatch\" style=\"background:").concat(shade.hex, "\"></span>\n      <span><strong>").concat(escapeHtml(shade.name), "</strong><small>").concat(escapeHtml(shade.family), " \xB7 ").concat(escapeHtml(shade.hex.toUpperCase()), "</small></span>\n      <em>").concat(escapeHtml(shade.code), "</em>\n    </button>\n  ");
  }).join("")).show();
}
function clearSearch() {
  dom.search.val("");
  dom.clearSearch.addClass("hidden");
  dom.suggestions.hide().empty();
}
function setupGsapIntro() {
  if (!window.gsap) return;
  gsap.from(".brand, .title-block, .search-wrap, .approve-btn", {
    y: -18,
    opacity: 0,
    duration: .55,
    ease: "power3.out",
    stagger: .05
  });
  gsap.from(".hero-copy > *, .control-row, .deck-section", {
    y: 22,
    opacity: 0,
    duration: .7,
    ease: "power3.out",
    stagger: .08,
    delay: .08
  });
}

// Desktop uses GSAP Draggable; mobile uses the native swipe fallback below.
function setupDraggable() {
  if (state.dragProxy) {
    state.dragProxy.kill();
    state.dragProxy = null;
  }
  dom.fanStage.off(".swipeBrowse");
  var isTouchDevice = window.matchMedia("(pointer: coarse)").matches || "ontouchstart" in window;
  if (isTouchDevice) {
    setupNativeSwipeBrowsing();
    return;
  }
  if (!window.gsap || !window.Draggable) {
    setupNativeSwipeBrowsing();
    return;
  }
  var proxy = document.createElement("div");
  var startIndex = 0;
  var lastX = 0;
  var hasDragged = false;
  state.dragProxy = Draggable.create(proxy, {
    trigger: dom.fanStage[0],
    type: "x",
    inertia: false,
    allowNativeTouchScrolling: true,
    minimumMovement: 6,
    onPress: function onPress() {
      state.isDragging = true;
      startIndex = state.selectedIndex;
      lastX = this.x;
      hasDragged = false;
      dom.fanStage.addClass("dragging");
    },
    onDrag: function onDrag() {
      var distance = this.x - lastX;
      if (Math.abs(distance) > 6) hasDragged = true;
      var stepSize = 28;
      var next = startIndex - Math.round(distance / stepSize);
      setSelectedIndex(next, {
        source: "drag"
      });
    },
    onRelease: function onRelease() {
      state.isDragging = false;
      dom.fanStage.removeClass("dragging");
      if (hasDragged) state.suppressFanClickUntil = Date.now() + 260;
      gsap.set(proxy, {
        x: 0
      });
    }
  })[0];
}

// Mobile swipe: horizontal movement browses shades; vertical movement scrolls the page.
function setupNativeSwipeBrowsing() {
  var stage = dom.fanStage[0];
  var active = false;
  var horizontal = false;
  var startX = 0;
  var startY = 0;
  var startIndex = 0;
  var pointerId = null;
  function beginSwipe(clientX, clientY, id) {
    active = true;
    horizontal = false;
    pointerId = id;
    startX = clientX;
    startY = clientY;
    startIndex = state.selectedIndex;
    state.isDragging = false;
    if (id !== null && id !== undefined && stage.setPointerCapture) {
      try {
        stage.setPointerCapture(id);
      } catch (_) {}
    }
  }
  function moveSwipe(clientX, clientY, event) {
    if (!active) return;
    var dx = clientX - startX;
    var dy = clientY - startY;
    if (!horizontal && Math.abs(dx) > 12 && Math.abs(dx) > Math.abs(dy) * 1.18) {
      horizontal = true;
      state.isDragging = true;
      dom.fanStage.addClass("dragging");
    }
    if (!horizontal) return;
    if (event && event.preventDefault) event.preventDefault();
    var stepSize = window.matchMedia("(max-width: 520px)").matches ? 28 : 34;
    var next = startIndex - Math.round(dx / stepSize);

    // requestAnimationFrame prevents repeated DOM work during fast touchmove
    // bursts, which is the main cause of mobile card blinking.
    state.swipePendingIndex = next;
    if (!state.swipeFrame) {
      state.swipeFrame = requestAnimationFrame(function () {
        setSelectedIndex(state.swipePendingIndex, {
          source: "touch-swipe"
        });
        state.swipeFrame = null;
      });
    }
  }
  function endSwipe() {
    if (!active) return;
    active = false;
    if (horizontal) state.suppressFanClickUntil = Date.now() + 320;
    horizontal = false;
    state.isDragging = false;
    dom.fanStage.removeClass("dragging");
    if (pointerId !== null && pointerId !== undefined && stage.releasePointerCapture) {
      try {
        stage.releasePointerCapture(pointerId);
      } catch (_) {}
    }
    if (state.swipeFrame) {
      cancelAnimationFrame(state.swipeFrame);
      state.swipeFrame = null;
      setSelectedIndex(state.swipePendingIndex, {
        source: "touch-swipe"
      });
    }
    state.swipePendingIndex = null;
    pointerId = null;
  }
  if (window.PointerEvent) {
    dom.fanStage.on("pointerdown.swipeBrowse", function (event) {
      var e = event.originalEvent;
      if (!e || e.pointerType === "mouse") return;
      beginSwipe(e.clientX, e.clientY, e.pointerId);
    });
    dom.fanStage.on("pointermove.swipeBrowse", function (event) {
      var e = event.originalEvent;
      if (!e) return;
      moveSwipe(e.clientX, e.clientY, event);
    });
    dom.fanStage.on("pointerup.swipeBrowse pointercancel.swipeBrowse pointerleave.swipeBrowse", endSwipe);
    return;
  }
  dom.fanStage.on("touchstart.swipeBrowse", function (event) {
    var _event$originalEvent;
    var touch = (_event$originalEvent = event.originalEvent) === null || _event$originalEvent === void 0 || (_event$originalEvent = _event$originalEvent.touches) === null || _event$originalEvent === void 0 ? void 0 : _event$originalEvent[0];
    if (!touch) return;
    beginSwipe(touch.clientX, touch.clientY, null);
  });
  dom.fanStage.on("touchmove.swipeBrowse", function (event) {
    var _event$originalEvent2;
    var touch = (_event$originalEvent2 = event.originalEvent) === null || _event$originalEvent2 === void 0 || (_event$originalEvent2 = _event$originalEvent2.touches) === null || _event$originalEvent2 === void 0 ? void 0 : _event$originalEvent2[0];
    if (!touch) return;
    moveSwipe(touch.clientX, touch.clientY, event);
  });
  dom.fanStage.on("touchend.swipeBrowse touchcancel.swipeBrowse", endSwipe);
}
function shouldSuppressFanClick() {
  return state.isDragging || Date.now() < state.suppressFanClickUntil;
}
function pulseDeck() {
  if (!window.gsap) return;
  gsap.fromTo(dom.fanDeck[0], {
    scale: .97
  }, {
    scale: 1,
    duration: .55,
    ease: "elastic.out(1, .6)"
  });
}
function setLoading(isLoading) {
  if (!isLoading) return;
  dom.progressText.text("Loading live Asian Paints colour catalogue...");
  dom.beaconName.text("Loading shades");
  dom.beaconMeta.text("Connecting to shade API");
}
function showDataError(message) {
  state.all = [];
  state.filtered = [];
  state.selectedId = null;
  dom.tabs.html("<button class=\"tab active\" type=\"button\">API unavailable</button>");
  dom.range.attr({
    min: 0,
    max: 0
  }).val(0);
  dom.rangeCount.text("0 / 0");
  dom.progressText.text("Live shade data unavailable");
  dom.shadeTotal.text("0 shades");
  dom.progressFill.css("width", "0%");
  dom.progressKnob.css("left", "0%");
  dom.beaconName.text("No live shades loaded");
  dom.beaconMeta.text("Check the API response");
  dom.activeFamily.text("API");
  dom.activeName.text("No colours found");
  dom.activeCode.text("The fandeck needs API shade data with HEX/RGB values.");
  dom.activeHex.text("--");
  dom.activeRgb.text("--");
  dom.fanDeck.html("\n    <div class=\"empty-tray api-empty\">\n      <strong>Shade API data needed</strong>\n      <span>".concat(escapeHtml(message), "</span>\n    </div>\n  "));
  renderSelectedPalette();
  setLoading(false);
  showToast("Live shade API unavailable. Check diagnostics or proxy setup.");
}
function uniqueList(list) {
  return _toConsumableArray(new Set(list.filter(Boolean)));
}
function getSelectedShade() {
  return state.filtered[state.selectedIndex] || null;
}
function copyToClipboard(value) {
  var _navigator$clipboard;
  if (!value) return;
  var done = function done() {
    return showToast("".concat(value, " copied."));
  };
  if ((_navigator$clipboard = navigator.clipboard) !== null && _navigator$clipboard !== void 0 && _navigator$clipboard.writeText) {
    navigator.clipboard.writeText(String(value)).then(done)["catch"](function () {
      return fallbackCopy(value, done);
    });
  } else {
    fallbackCopy(value, done);
  }
}
function fallbackCopy(value, done) {
  var input = document.createElement("textarea");
  input.value = value;
  input.style.position = "fixed";
  input.style.opacity = "0";
  document.body.appendChild(input);
  input.select();
  document.execCommand("copy");
  document.body.removeChild(input);
  done();
}
function showToast(message) {
  dom.toast.text(message).addClass("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(function () {
    return dom.toast.removeClass("show");
  }, 2200);
}
function debounce(fn, wait) {
  var timer;
  return function debounced() {
    var _this = this;
    for (var _len = arguments.length, args = new Array(_len), _key2 = 0; _key2 < _len; _key2++) {
      args[_key2] = arguments[_key2];
    }
    clearTimeout(timer);
    timer = setTimeout(function () {
      return fn.apply(_this, args);
    }, wait);
  };
}
function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}
function cleanText(value) {
  if (value === null || value === undefined) return "";
  return String(value).replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim();
}
function normalizeFamily(family) {
  var text = cleanText(family) || "Other";
  var known = {
    grey: "Grey",
    gray: "Grey",
    blue: "Blue",
    brown: "Brown",
    red: "Pink And Red",
    pink: "Pink And Red",
    "pink and red": "Pink And Red",
    orange: "Orange",
    yellow: "Yellow",
    green: "Green",
    teal: "Teal",
    purple: "Purple",
    white: "Whites",
    whites: "Whites",
    "off white": "Off Whites",
    "off whites": "Off Whites",
    neutral: "Neutrals",
    neutrals: "Neutrals"
  };
  var lower = text.toLowerCase();
  return known[lower] || text.replace(/\b\w/g, function (_char) {
    return _char.toUpperCase();
  });
}
function autoFamily(hex) {
  var _hexToRgb = hexToRgb(hex),
    r = _hexToRgb.r,
    g = _hexToRgb.g,
    b = _hexToRgb.b;
  var _rgbToHsl = rgbToHsl(r, g, b),
    h = _rgbToHsl.h,
    s = _rgbToHsl.s,
    l = _rgbToHsl.l;
  if (l > 92 && s < 30) return "Whites";
  if (s < 12) return "Grey";
  if (h >= 345 || h < 14) return "Pink And Red";
  if (h < 42) return "Orange";
  if (h < 68) return "Yellow";
  if (h < 145) return "Green";
  if (h < 188) return "Teal";
  if (h < 245) return "Blue";
  if (h < 304) return "Purple";
  return "Pink And Red";
}
function isLikelyFamilyName(key) {
  var normalized = key.toLowerCase();
  return ["grey", "gray", "blue", "brown", "red", "pink", "pink and red", "orange", "yellow", "green", "teal", "purple", "whites", "white", "off whites", "off white", "neutral", "neutrals"].includes(normalized);
}
function prettifyKey(key) {
  return cleanText(key.replace(/([a-z])([A-Z])/g, "$1 $2"));
}
function normalizeHex(value) {
  if (!value) return null;
  var hex = String(value).trim();
  if (/^[0-9a-f]{6}$/i.test(hex)) hex = "#".concat(hex);
  if (/^[0-9a-f]{3}$/i.test(hex)) hex = "#".concat(hex);
  if (!/^#[0-9a-f]{3}([0-9a-f]{3})?$/i.test(hex)) return null;
  if (hex.length === 4) {
    hex = "#".concat(hex[1]).concat(hex[1]).concat(hex[2]).concat(hex[2]).concat(hex[3]).concat(hex[3]);
  }
  return hex.toLowerCase();
}
function hexToRgb(hex) {
  var safe = normalizeHex(hex) || "#000000";
  var value = safe.slice(1);
  return {
    r: parseInt(value.slice(0, 2), 16),
    g: parseInt(value.slice(2, 4), 16),
    b: parseInt(value.slice(4, 6), 16)
  };
}
function rgbToHex(r, g, b) {
  return "#".concat([r, g, b].map(function (num) {
    return clamp(Math.round(num), 0, 255).toString(16).padStart(2, "0");
  }).join(""));
}
function rgbArrayToHex(arr) {
  if (arr.length < 3) return null;
  return rgbToHex(Number(arr[0]), Number(arr[1]), Number(arr[2]));
}
function rgbStringToHex(value) {
  var matches = String(value).match(/\d+(?:\.\d+)?/g);
  if (!matches || matches.length < 3) return null;
  return rgbToHex(Number(matches[0]), Number(matches[1]), Number(matches[2]));
}
function rgbToHsl(r, g, b) {
  r /= 255;
  g /= 255;
  b /= 255;
  var max = Math.max(r, g, b);
  var min = Math.min(r, g, b);
  var h = 0;
  var s = 0;
  var l = (max + min) / 2;
  if (max !== min) {
    var d = max - min;
    s = l > .5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
      default:
        h = 0;
    }
    h /= 6;
  }
  return {
    h: h * 360,
    s: s * 100,
    l: l * 100
  };
}
function hslToRgb(h, s, l) {
  h = (h % 360 + 360) % 360 / 360;
  s = clamp(s, 0, 100) / 100;
  l = clamp(l, 0, 100) / 100;
  if (s === 0) {
    var value = Math.round(l * 255);
    return {
      r: value,
      g: value,
      b: value
    };
  }
  var hue2rgb = function hue2rgb(p, q, t) {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };
  var q = l < .5 ? l * (1 + s) : l + s - l * s;
  var p = 2 * l - q;
  return {
    r: Math.round(hue2rgb(p, q, h + 1 / 3) * 255),
    g: Math.round(hue2rgb(p, q, h) * 255),
    b: Math.round(hue2rgb(p, q, h - 1 / 3) * 255)
  };
}
function shiftColor(hex) {
  var lightnessDelta = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var saturationDelta = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  if (window.tinycolor) {
    var color = tinycolor(hex);
    if (lightnessDelta >= 0) color.lighten(lightnessDelta);else color.darken(Math.abs(lightnessDelta));
    if (saturationDelta >= 0) color.saturate(saturationDelta);else color.desaturate(Math.abs(saturationDelta));
    return color.toHexString();
  }
  var rgb = hexToRgb(hex);
  var hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
  var shifted = hslToRgb(hsl.h, hsl.s + saturationDelta, hsl.l + lightnessDelta);
  return rgbToHex(shifted.r, shifted.g, shifted.b);
}
function shiftHue(hex) {
  var hueDelta = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var lightnessDelta = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  var saturationDelta = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
  if (window.tinycolor) {
    var color = tinycolor(hex).spin(hueDelta);
    if (lightnessDelta >= 0) color.lighten(lightnessDelta);else color.darken(Math.abs(lightnessDelta));
    if (saturationDelta >= 0) color.saturate(saturationDelta);else color.desaturate(Math.abs(saturationDelta));
    return color.toHexString();
  }
  var rgb = hexToRgb(hex);
  var hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
  var shifted = hslToRgb(hsl.h + hueDelta, hsl.s + saturationDelta, hsl.l + lightnessDelta);
  return rgbToHex(shifted.r, shifted.g, shifted.b);
}
function readableText(hex) {
  var _hexToRgb2 = hexToRgb(hex),
    r = _hexToRgb2.r,
    g = _hexToRgb2.g,
    b = _hexToRgb2.b;
  var luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > .58 ? "#0f172a" : "#ffffff";
}
function familyAccent() {
  var family = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "All";
  var lower = String(family).toLowerCase();
  if (lower.includes("all")) return "#ed1c24";
  if (lower.includes("blue")) return "#1d6fb8";
  if (lower.includes("brown")) return "#8b5a3c";
  if (lower.includes("grey") || lower.includes("gray")) return "#64748b";
  if (lower.includes("orange")) return "#f97316";
  if (lower.includes("pink") || lower.includes("red")) return "#db2777";
  if (lower.includes("purple") || lower.includes("violet")) return "#7c3aed";
  if (lower.includes("green")) return "#16a34a";
  if (lower.includes("teal")) return "#0f9f9a";
  if (lower.includes("yellow")) return "#ca8a04";
  if (lower.includes("white")) return "#94a3b8";
  if (lower.includes("neutral")) return "#a16207";
  return "#ed1c24";
}
function hexToRgba(hex) {
  var alpha = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
  var rgb = hexToRgb(hex);
  return "rgba(".concat(rgb.r, ", ").concat(rgb.g, ", ").concat(rgb.b, ", ").concat(clamp(alpha, 0, 1), ")");
}
function relativeLuminance(hex) {
  var _hexToRgb3 = hexToRgb(hex),
    r = _hexToRgb3.r,
    g = _hexToRgb3.g,
    b = _hexToRgb3.b;
  var convert = function convert(value) {
    var channel = value / 255;
    return channel <= 0.03928 ? channel / 12.92 : Math.pow((channel + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * convert(r) + 0.0722 * convert(b) + 0.7152 * convert(g);
}
function contrastRatio(backgroundHex, textHex) {
  var bg = relativeLuminance(backgroundHex);
  var fg = relativeLuminance(textHex);
  var lighter = Math.max(bg, fg);
  var darker = Math.min(bg, fg);
  return (lighter + 0.05) / (darker + 0.05);
}
function contrastGrade(ratio) {
  if (ratio >= 7) return "AAA";
  if (ratio >= 4.5) return "AA";
  if (ratio >= 3) return "Large";
  return "Low";
}
function shortCode(code, offset) {
  var clean = String(code || "").replace(/\s+/g, "");
  if (clean.length <= 6) return offset ? "".concat(clean) : clean;
  return "".concat(clean.slice(0, 4)).concat(offset);
}
function slugify(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "shade";
}
function escapeHtml(value) {
  return String(value !== null && value !== void 0 ? value : "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, "&#096;");
}
function cssEscape(value) {
  var _window$CSS;
  if ((_window$CSS = window.CSS) !== null && _window$CSS !== void 0 && _window$CSS.escape) return CSS.escape(String(value));
  return String(value).replace(/"/g, "\\\"");
}
