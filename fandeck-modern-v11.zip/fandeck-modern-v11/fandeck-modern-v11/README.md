# Asian Paints Digital Fandeck

Responsive fandeck UI built with HTML, SCSS/CSS, jQuery, GSAP, Draggable, and TinyColor.

## Run locally

```bash
npm install
npm start
```

Open:

```text
http://127.0.0.1:8000
```

You can also keep VS Code Live Server open on `http://127.0.0.1:5500`, but `npm start` must still be running. The frontend will call `http://127.0.0.1:8000/api/shades`, and the Node proxy now allows local CORS.

## SCSS

Edit `style.scss` first, then compile:

```bash
npm run build:css
```

For live CSS rebuilds:

```bash
npm run watch:css
```

## API strategy

- On `beta.asianpaints.com`, the frontend first tries the same-origin AEM shade JSON path.
- On localhost, the frontend uses `/api/shades` through `server.js`.
- The proxy tries `beta.asianpaints.com` first and then `www.asianpaints.com` as a secondary live source.
- No demo/hardcoded shade fallback is injected. If no live source returns usable HEX/RGB colours, the UI shows an API-needed state.

Diagnostics:

```text
http://127.0.0.1:8000/api/shades/diagnostics
```

## v11 UI polish

- `--brand` is now `#075da7` for the latest blue-led interface direction.
- The fan-card cap code is centred.
- The bottom browse console no longer overlaps the fan canvas.
- The fandeck is visually pushed upward to leave space for the selected shade and controls.
- The old Favorites action has been repurposed as a clearer Shortlisted filter.
- The bottom colour-selection tray now includes a Review CTA.
- Smart palette tiles now show the generated colour name, not just the swatch/contrast badge.
