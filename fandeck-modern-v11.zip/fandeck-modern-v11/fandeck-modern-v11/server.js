#!/usr/bin/env node
/**
 * Asian Paints Digital Fandeck local server.
 * ------------------------------------------------------------
 * Purpose:
 * - Local development cannot reliably fetch Asian Paints AEM JSON directly
 *   because browser CORS can block cross-domain JSON reads.
 * - This small Node server exposes /api/shades from the same local origin.
 * - It also supports Live Server / Vite style frontends by returning CORS
 *   headers for localhost origins such as http://127.0.0.1:5500.
 *
 * Production note:
 * - When this code is hosted inside beta.asianpaints.com, server.js is not
 *   required if the page can call the AEM JSON path on the same domain.
 * - If the page is hosted on any other domain, keep a proxy route like this.
 *
 * Data rule:
 * - This file does not inject demo shade colours. It only normalises colours
 *   returned by the live Asian Paints JSON sources.
 */

const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = Number(process.env.PORT || 8000);
const ROOT = __dirname;

// Try beta first because the target deployment is beta.asianpaints.com.
// If beta has not published the shade JSON yet, the proxy then tries www.
const DEFAULT_BASES = "https://beta.asianpaints.com,https://www.asianpaints.com";
const AP_BASE_URLS = String(process.env.AP_BASE_URLS || process.env.AP_BASE_URL || DEFAULT_BASES)
  .split(",")
  .map(url => url.trim().replace(/\/$/, ""))
  .filter(Boolean);

const SHADE_API_PATHS = [
  "/content/ap/en/home/colour-catalogue/jcr%3Acontent/root/responsivegrid_602603264/shadelisting.shade.json?selectedShadeFamily=all&language=en&shadeMapper=false",
  "/content/ap/en/home/colour-catalogue/jcr:content/root/responsivegrid_602603264/shadelisting.shade.json?selectedShadeFamily=all&language=en&shadeMapper=false"
];

const CACHE_TTL_MS = Number(process.env.SHADE_CACHE_TTL_MS || 10 * 60 * 1000);

let cacheBody = null;
let cacheTime = 0;
let diagnosticCache = null;

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".scss": "text/x-scss; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml; charset=utf-8",
  ".ico": "image/x-icon",
  ".webp": "image/webp",
};

const NAME_KEYS = [
  "shadeName", "shade_name", "shadename", "name", "colourName", "colorName",
  "title", "shadeTitle", "label", "shade", "displayName", "productName",
  "colorLabel", "colourLabel", "entityName"
];
const CODE_KEYS = [
  "shadeCode", "shade_code", "shadecode", "code", "shadeNo", "shadeNumber",
  "shadeNbr", "shadeNum", "colourCode", "colorCode", "colour_code",
  "color_code", "shadeId", "id", "sapCode", "sku", "colorId", "colourId", "entityCode"
];
const FAMILY_KEYS = [
  "shadeFamily", "shadefamily", "shadeFamilyName", "shade_family", "family",
  "familyName", "colourFamily", "colorFamily", "colourFamilyName",
  "colorFamilyName", "filterName", "category", "categoryName", "shadeGroup",
  "shadeGroupName", "groupName", "entityType", "colourFamilyName"
];
const HEX_KEYS = [
  "hex", "hexCode", "hexcode", "shadeHex", "shadeHexCode", "shadeHexadecimalCode",
  "hexadecimal", "hexadecimalCode", "colorHex", "colourHex", "colorHexCode",
  "colourHexCode", "htmlColor", "htmlColour", "rgbHexCode", "rgbHex", "webHex",
  "swatchHex", "shadeRGB", "shadeRgb", "rgb", "rgbValue", "rgbCode", "rgbcode",
  "rgb_code", "shadeRGBValue", "shadeRgbValue", "colorRgb", "colourRgb", "colorRGB",
  "colourRGB", "shadeColor", "shadeColour", "background", "backgroundColor", "bgColor",
  "color", "colour", "value", "entityColour", "entityColor"
];

function apiCorsHeaders(req) {
  const origin = req.headers.origin || "";
  const isLocalOrigin = /^https?:\/\/(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?$/i.test(origin);
  if (!isLocalOrigin) return {};
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Accept",
    "Access-Control-Max-Age": "86400",
  };
}

function send(res, status, body, headers = {}) {
  res.writeHead(status, headers);
  res.end(body);
}

function sendJson(res, status, data, headers = {}) {
  send(res, status, JSON.stringify(data, null, 2), {
    "Content-Type": "application/json; charset=utf-8",
    ...headers,
  });
}

async function fetchRemoteJsonText(source) {
  const response = await fetch(source.remoteUrl, {
    headers: {
      Accept: "application/json,text/plain,*/*",
      Referer: `${source.baseUrl}/colour-catalogue.html`,
      "User-Agent": "Mozilla/5.0 (compatible; AsianPaintsFandeckProxy/1.1; +http://localhost)",
    },
  });

  const text = await response.text();
  return {
    status: response.status,
    ok: response.ok,
    contentType: response.headers.get("content-type") || "",
    text,
  };
}

function sourceList() {
  const sources = [];
  for (const baseUrl of AP_BASE_URLS) {
    for (const apiPath of SHADE_API_PATHS) {
      sources.push({
        baseUrl,
        apiPath,
        remoteUrl: `${baseUrl}${apiPath}`,
      });
    }
  }
  return sources;
}

async function loadShadesFromApi() {
  const diagnostics = {
    checkedAt: new Date().toISOString(),
    baseUrls: AP_BASE_URLS,
    attemptedSources: [],
    selectedSource: null,
    candidateCount: 0,
    usableCount: 0,
    warnings: [],
  };

  for (const source of sourceList()) {
    const attempt = {
      baseUrl: source.baseUrl,
      jsonUrl: source.remoteUrl,
      status: null,
      contentType: null,
      textLength: 0,
      topLevel: null,
      topKeys: [],
      candidateCount: 0,
      usableCount: 0,
      warnings: [],
    };
    diagnostics.attemptedSources.push(attempt);

    try {
      const remote = await fetchRemoteJsonText(source);
      attempt.status = remote.status;
      attempt.contentType = remote.contentType;
      attempt.textLength = remote.text.length;

      if (!remote.ok) {
        attempt.warnings.push(`Remote API returned HTTP ${remote.status}.`);
        continue;
      }

      const payload = parsePossiblyWrappedJson(remote.text);
      attempt.topLevel = Array.isArray(payload) ? "array" : typeof payload;
      attempt.topKeys = payload && typeof payload === "object" && !Array.isArray(payload) ? Object.keys(payload).slice(0, 40) : [];

      const candidates = Array.isArray(payload?.shades) ? payload.shades : extractShadeObjects(payload);
      const shades = prepareShades(candidates);

      attempt.candidateCount = candidates.length;
      attempt.usableCount = shades.length;
      diagnostics.candidateCount += candidates.length;
      diagnostics.usableCount += shades.length;

      if (shades.length) {
        diagnostics.selectedSource = source.remoteUrl;
        diagnosticCache = diagnostics;
        return {
          shades,
          meta: {
            source: source.baseUrl.includes("beta.asianpaints.com") ? "beta-asianpaints-aem-json" : "asianpaints-aem-json",
            baseUrl: source.baseUrl,
            remoteUrl: source.remoteUrl,
            count: shades.length,
            diagnostics: "/api/shades/diagnostics",
          },
          diagnostics,
        };
      }

      attempt.warnings.push("JSON was reachable but had no normalisable colour entries with HEX/RGB.");
    } catch (error) {
      attempt.warnings.push(error.message);
    }
  }

  diagnostics.warnings.push("No attempted Asian Paints JSON source returned usable colour objects. No hardcoded fallback shades were used.");
  diagnosticCache = diagnostics;
  return {
    shades: [],
    meta: {
      source: "no-usable-live-source",
      count: 0,
      diagnostics: "/api/shades/diagnostics",
    },
    diagnostics,
  };
}

async function handleShadeProxy(req, res) {
  const cors = apiCorsHeaders(req);
  if (req.method === "OPTIONS") return send(res, 204, "", cors);
  if (req.method !== "GET") return sendJson(res, 405, { error: "Method not allowed" }, cors);

  const now = Date.now();
  if (cacheBody && now - cacheTime < CACHE_TTL_MS) {
    return send(res, 200, cacheBody, {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "public, max-age=300",
      "X-Proxy-Cache": "HIT",
      ...cors,
    });
  }

  try {
    const payload = await loadShadesFromApi();
    if (!payload.shades.length) {
      return sendJson(res, 502, {
        error: "The Asian Paints shade API returned no usable colour objects.",
        meta: payload.meta,
        diagnostics: payload.diagnostics,
      }, { "Cache-Control": "no-cache", ...cors });
    }

    cacheBody = JSON.stringify({ shades: payload.shades, meta: payload.meta });
    cacheTime = now;
    return send(res, 200, cacheBody, {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "public, max-age=300",
      "X-Proxy-Cache": "MISS",
      ...cors,
    });
  } catch (error) {
    return sendJson(res, 502, {
      error: "Could not load live shade data from Asian Paints.",
      detail: error.message,
      diagnostics: diagnosticCache,
    }, { "Cache-Control": "no-cache", ...cors });
  }
}

async function handleDiagnostics(req, res) {
  const cors = apiCorsHeaders(req);
  if (req.method === "OPTIONS") return send(res, 204, "", cors);
  if (req.method !== "GET") return sendJson(res, 405, { error: "Method not allowed" }, cors);
  if (!diagnosticCache) {
    try { await loadShadesFromApi(); }
    catch (error) { diagnosticCache = diagnosticCache || { checkedAt: new Date().toISOString(), error: error.message }; }
  }
  return sendJson(res, 200, diagnosticCache || {}, { "Cache-Control": "no-cache", ...cors });
}

function serveStatic(req, res) {
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, `http://localhost:${PORT}`).pathname); }
  catch (_) { return sendJson(res, 400, { error: "Bad URL" }); }

  const safePath = pathname === "/" ? "/index.html" : pathname;
  const filePath = path.normalize(path.join(ROOT, safePath));
  if (!filePath.startsWith(ROOT)) return sendJson(res, 403, { error: "Forbidden" });

  fs.readFile(filePath, (error, data) => {
    if (error) return sendJson(res, 404, { error: "Not found" });
    send(res, 200, data, { "Content-Type": MIME_TYPES[path.extname(filePath).toLowerCase()] || "application/octet-stream" });
  });
}

function parsePossiblyWrappedJson(text) {
  const trimmed = String(text || "").trim();
  if (!trimmed) throw new Error("Remote API returned an empty response.");
  const cleaned = trimmed.replace(/^\)\]\}'\s*,?\s*/, "");
  try { return JSON.parse(cleaned); }
  catch (error) { throw new Error(`Remote API did not return valid JSON. First characters: ${cleaned.slice(0, 80)}`); }
}

function extractShadeObjects(payload) {
  const result = [];
  const seen = new WeakSet();

  function walk(node, context = {}) {
    if (!node || typeof node !== "object") return;
    if (seen.has(node)) return;
    seen.add(node);

    if (Array.isArray(node)) {
      node.forEach(child => walk(child, context));
      return;
    }

    const family = cleanText(readAny(node, FAMILY_KEYS)) || context.family || "";
    const nextContext = { ...context, family };

    if (looksLikeShade(node)) result.push({ ...node, __contextFamily: family });

    Object.entries(node).forEach(([key, value]) => {
      const pretty = prettifyKey(key);
      const childContext = isLikelyFamilyName(pretty) ? { ...nextContext, family: pretty } : nextContext;
      walk(value, childContext);
    });
  }

  walk(payload);
  return result;
}

function looksLikeShade(obj) {
  const hasNameOrCode = Boolean(readAny(obj, NAME_KEYS) || readAny(obj, CODE_KEYS));
  const hasColor = Boolean(extractHex(obj));
  return hasNameOrCode && hasColor;
}

function prepareShades(list) {
  const seen = new Set();
  const shades = [];
  list.forEach((item, index) => {
    const shade = normalizeShade(item, index);
    if (!shade) return;
    const key = `${shade.code}|${shade.name}|${shade.hex}`.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    shades.push(shade);
  });
  return shades.sort((a, b) => a.family.localeCompare(b.family) || a.name.localeCompare(b.name));
}

function normalizeShade(obj, index) {
  const hex = normalizeHex(extractHex(obj));
  if (!hex) return null;
  const code = cleanText(readAny(obj, CODE_KEYS)) || `API-${String(index + 1).padStart(4, "0")}`;
  const name = cleanText(readAny(obj, NAME_KEYS)) || `Shade ${code}`;
  const rawFamily = cleanText(readAny(obj, FAMILY_KEYS)) || obj.__contextFamily || autoFamily(hex);
  const normalizedFamily = normalizeFamily(rawFamily);
  const family = normalizedFamily === "All" ? autoFamily(hex) : normalizedFamily;
  const rgb = hexToRgb(hex);
  return {
    id: `${slugify(code)}-${slugify(name)}-${index}`,
    name,
    code: String(code).trim(),
    hex,
    family,
    rgb,
    rgbText: `${rgb.r}, ${rgb.g}, ${rgb.b}`,
    source: "api",
  };
}

function extractHex(obj) {
  const direct = readAny(obj, HEX_KEYS);
  if (Array.isArray(direct)) return rgbArrayToHex(direct);
  if (typeof direct === "object" && direct) {
    const nestedHex = readAny(direct, HEX_KEYS);
    if (nestedHex && nestedHex !== direct) return nestedHex;
    if (["r", "g", "b"].every(key => key in direct)) return rgbToHex(Number(direct.r), Number(direct.g), Number(direct.b));
    if (["red", "green", "blue"].every(key => key in direct)) return rgbToHex(Number(direct.red), Number(direct.green), Number(direct.blue));
  }
  if (typeof direct === "string") {
    if (/rgb\s*\(/i.test(direct)) return rgbStringToHex(direct);
    const numericTriple = direct.match(/^\s*(\d{1,3})\s*[,| ]\s*(\d{1,3})\s*[,| ]\s*(\d{1,3})\s*$/);
    if (numericTriple) return rgbToHex(Number(numericTriple[1]), Number(numericTriple[2]), Number(numericTriple[3]));
    const styleHex = direct.match(/background(?:-color)?\s*:\s*(#[0-9a-f]{3,8}|rgba?\([^)]+\))/i)?.[1];
    if (styleHex) return /rgb\s*\(/i.test(styleHex) ? rgbStringToHex(styleHex) : styleHex;
    const embeddedHex = direct.match(/#[0-9a-f]{3}(?:[0-9a-f]{3})?\b/i)?.[0] || direct.match(/\b[0-9a-f]{6}\b/i)?.[0];
    return embeddedHex || direct;
  }

  const triples = [
    ["r", "g", "b"], ["R", "G", "B"], ["red", "green", "blue"], ["Red", "Green", "Blue"],
    ["shadeR", "shadeG", "shadeB"], ["shadeRed", "shadeGreen", "shadeBlue"],
    ["redValue", "greenValue", "blueValue"], ["rValue", "gValue", "bValue"]
  ];
  for (const [rk, gk, bk] of triples) {
    const r = readAny(obj, [rk]);
    const g = readAny(obj, [gk]);
    const b = readAny(obj, [bk]);
    if ([r, g, b].every(value => value !== null && value !== undefined && value !== "" && !Number.isNaN(Number(value)))) {
      return rgbToHex(Number(r), Number(g), Number(b));
    }
  }
  return null;
}

function readAny(obj, keys) {
  if (!obj || typeof obj !== "object") return null;
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(obj, key) && obj[key] !== null && obj[key] !== undefined && obj[key] !== "") return obj[key];
  }
  const lowerMap = Object.keys(obj).reduce((acc, key) => { acc[key.toLowerCase()] = key; return acc; }, {});
  for (const key of keys) {
    const actual = lowerMap[key.toLowerCase()];
    if (actual && obj[actual] !== null && obj[actual] !== undefined && obj[actual] !== "") return obj[actual];
  }
  return null;
}

function normalizeHex(value) {
  if (!value && value !== 0) return null;
  let hex = String(value).trim();
  if (/^rgba?\(/i.test(hex)) return rgbStringToHex(hex);
  const embedded = hex.match(/#[0-9a-f]{3}(?:[0-9a-f]{3})?\b/i)?.[0] || hex.match(/\b[0-9a-f]{6}\b/i)?.[0];
  if (embedded) hex = embedded;
  if (!hex.startsWith("#")) hex = `#${hex}`;
  if (/^#[0-9a-f]{3}$/i.test(hex)) hex = `#${hex.slice(1).split("").map(ch => ch + ch).join("")}`;
  if (!/^#[0-9a-f]{6}$/i.test(hex)) return null;
  return hex.toUpperCase();
}

function rgbStringToHex(value) {
  const nums = String(value).match(/\d+(?:\.\d+)?/g)?.slice(0, 3).map(Number);
  if (!nums || nums.length < 3) return null;
  return rgbToHex(nums[0], nums[1], nums[2]);
}

function rgbArrayToHex(arr) {
  if (arr.length < 3) return null;
  return rgbToHex(Number(arr[0]), Number(arr[1]), Number(arr[2]));
}

function rgbToHex(r, g, b) {
  if ([r, g, b].some(value => !Number.isFinite(value))) return null;
  return `#${[r, g, b].map(value => Math.max(0, Math.min(255, Math.round(value))).toString(16).padStart(2, "0")).join("")}`.toUpperCase();
}

function hexToRgb(hex) {
  const clean = normalizeHex(hex)?.replace("#", "") || "000000";
  return { r: parseInt(clean.slice(0, 2), 16), g: parseInt(clean.slice(2, 4), 16), b: parseInt(clean.slice(4, 6), 16) };
}

function autoFamily(hex) {
  const { r, g, b } = hexToRgb(hex);
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  if (max - min < 24) return "Grey";
  if (r > 210 && g > 210 && b > 200) return "Whites";
  if (r > g && r > b) return b > g + 22 ? "Pink And Red" : "Orange";
  if (g > r && g > b) return b > r + 20 ? "Teal" : "Green";
  if (b > r && b > g) return r > g + 20 ? "Purple" : "Blue";
  return "Other";
}

function normalizeFamily(family) {
  const text = cleanText(family) || "Other";
  const map = {
    all: "All", blues: "Blue", blue: "Blue", greys: "Grey", grey: "Grey", grays: "Grey", gray: "Grey",
    browns: "Brown", brown: "Brown", reds: "Pink And Red", red: "Pink And Red", pinks: "Pink And Red", pink: "Pink And Red",
    oranges: "Orange", orange: "Orange", yellows: "Yellow", yellow: "Yellow", greens: "Green", green: "Green",
    teals: "Teal", teal: "Teal", purples: "Purple", purple: "Purple", whites: "Whites", white: "Whites",
    "off whites": "Off Whites", "off white": "Off Whites", neutrals: "Neutral", neutral: "Neutral"
  };
  const key = text.toLowerCase().replace(/&/g, "and").replace(/\s+/g, " ").trim();
  return map[key] || text.replace(/\b\w/g, char => char.toUpperCase());
}

function isLikelyFamilyName(text) {
  return /blue|grey|gray|brown|red|orange|yellow|green|purple|pink|white|neutral|teal/i.test(text || "");
}

function cleanText(value) {
  if (value === null || value === undefined) return "";
  return String(value).replace(/<[^>]+>/g, " ").replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
}

function prettifyKey(key) {
  return cleanText(String(key).replace(/[-_]+/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2"));
}

function slugify(value) {
  return cleanText(value).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "shade";
}


const server = http.createServer((req, res) => {
  const pathname = new URL(req.url, `http://localhost:${PORT}`).pathname;
  if (pathname === "/api/shades") return handleShadeProxy(req, res);
  if (pathname === "/api/shades/diagnostics") return handleDiagnostics(req, res);
  return serveStatic(req, res);
});

server.listen(PORT, () => {
  console.log(`Asian Paints fandeck running at http://127.0.0.1:${PORT}`);
  console.log(`Proxy target order: ${AP_BASE_URLS.join(", ")}`);
  console.log("Tip: open this same URL, or keep Live Server open and let it call this proxy with localhost CORS.");
});
